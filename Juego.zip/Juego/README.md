# Juego de Rol Satírico – Democracia Edition

Este proyecto es un **juego de rol por turnos** ambientado en una versión humorística y exagerada de la vida pública y administrativa española. El objetivo es crear criaturas únicas, equiparlas con armas absurdas, escudos burocráticos y pócimas ridículas, y avanzar a través de combates y eventos inspirados en la sátira política y social.

## Características principales

- **Sistema de combate por turnos** con tiradas de dado, ataque, defensa y cálculo de daño.
- **Más de 100 razas satíricas**, cada una con atributos propios.
- **Armas y escudos divididos por niveles**, con más de 180 objetos en total.
- **99 pócimas curativas** con efectos y nombres humorísticos.
- **Sistema de creación de criaturas** mediante factorías:  
  - Criaturas únicas sin repetir raza, nombre ni equipamiento.  
  - Equipamiento aleatorio por nivel.  
  - Gestión de vida máxima, daño y recuperación.
- **Estructura modular** con interfaces para armas, escudos, razas, pócimas y criaturas.
- **Sistema de excepciones personalizado** para controlar efectos como vida máxima o malgasto de pócimas.

## Tecnologías utilizadas

- **Java 21**
- **Maven**
- **Lombok**
- **Logback**
- **Eclipse IDE**

## Estado del proyecto

El juego se encuentra en desarrollo activo.  
Se está ampliando el contenido jugable y afinando el motor de criaturas, habilidades y flujo de combate.

## Licencia

Este repositorio **no tiene licencia**, por lo que **todos los derechos están reservados**.  
No se permite el uso, copia, modificación o distribución del código sin autorización expresa.
