package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.capitulo.Capitulos;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.criatura.Criaturas;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Flujo responsable de crear un capítulo completo:
 *  - Generar los eventos de la temática (1..n)
 *  - Generar los datos base del villano
 *  - Ensamblar la CriaturaVillano mediante la fachada del dominio
 *  - Crear el capítulo a través de la fachada de dominio
 *
 * Package-private.
 */
final class FlujoCrearCapitulo {

    private FlujoCrearCapitulo() {}

    static DTOCapitulo crear(
            TematicaEventos tematica,
            ContextoCreacion ctx,
            int numItemsPorTipoVillano,
            int pvMaxVillano,
            int experienciaVillano,
            int numeroEventos    
    ) {

        // ============================
        // 1. Crear los eventos (N por capítulo)
        // ============================
        DTOEventos dtoEventos = FlujoCrearEvento.crear(tematica, numeroEventos);
        List<Evento> eventos = dtoEventos.eventos();

        // ============================
        // 2. Crear datos base del villano
        // ============================
        DTOVillano dtoVillano = FlujoCreacionVillano.crear(
                tematica,
                ctx,
                numItemsPorTipoVillano,
                pvMaxVillano,
                experienciaVillano
        );

        // ============================
        // 3. Ensamblar la Criatura del villano via dominio
        // ============================
        Criatura villanoFinal = Criaturas.crear(
                dtoVillano.nombre(),
                dtoVillano.experiencia(),
                dtoVillano.raza(),
                dtoVillano.pvMax(),   // pv actual
                dtoVillano.pvMax(),   // pv máximo
                dtoVillano.armas(),
                dtoVillano.escudos(),
                dtoVillano.pociones(),
                dtoVillano.inventarioPasivoArmas(),
                dtoVillano.inventarioPasivoEscudos(),
                dtoVillano.inventarioPasivoPociones()
        );

        // ============================
        // 4. Crear el capítulo de dominio (con N eventos)
        // ============================
        Capitulo capitulo = Capitulos.crearOReconstruir(
                tematica,
                eventos,        // ✔ Ahora se pasa la lista completa
                villanoFinal
        );

        // ============================
        // 5. Retornar DTO
        // ============================
        return new DTOCapitulo(capitulo);
    }
}
