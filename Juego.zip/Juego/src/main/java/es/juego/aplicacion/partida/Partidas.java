package es.juego.aplicacion.partida;

import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;

public final class Partidas {

    private Partidas() {}

    public static Partida crear(Historia historiaInicial, List<Criatura> heroes) {
        return new PartidaBase(historiaInicial, heroes);
    }

    public static Partida reconstruir(
            Historia historia,
            List<Criatura> heroes,
            Jugador... jugadores
    ) {
        PartidaBase p = new PartidaBase(historia, heroes);
        if (jugadores != null) {
            for (Jugador j : jugadores) {
                p.agregarJugador(j);
            }
        }
        return p;
    }
}
