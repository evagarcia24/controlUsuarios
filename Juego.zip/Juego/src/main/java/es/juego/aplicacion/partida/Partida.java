package es.juego.aplicacion.partida;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;

/**
 * Representa una partida en curso desde el punto de vista de lectura.
 *
 * Es la API que la capa superior (UI o controladores) utilizará para consultar
 * el estado del juego.
 *
 * No expone mutabilidad; la evolución de la partida se gestiona desde
 * flujos específicos y desde las clases internas del paquete.
 */
public interface Partida {

    /**
     * Jugadores involucrados en la partida.
     */
    List<Jugador> getJugadores();
    
    /**
     * Lista de héroes participantes en la partida.
     */
    List<Criatura> getHeroes();

    /**
     * Historia que se está jugando actualmente.
     */
    Historia getHistoria();

    /**
     * Capítulo actual de la historia.
     */
    Capitulo getCapituloActual();

    /**
     * Devuelve el villano final de la historia si ya existe;
     * en caso contrario, puede ser null.
     */
    Criatura getVillanoFinal();

    /**
     * Indica si la historia ya ha terminado por completo.
     * La condición interna exacta la decide la implementación.
     */
    boolean historiaCompleta();
}
