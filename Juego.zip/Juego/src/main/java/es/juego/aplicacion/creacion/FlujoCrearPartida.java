package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.aplicacion.partida.Partida;
import es.juego.aplicacion.partida.Partidas;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;
import es.juego.dominio.historia.Historias;

/**
 * Flujo principal para crear una {@link Partida} completa.
 *
 * Orquesta:
 *  - el {@link ContextoCreacion}
 *  - la creación de héroes
 *  - la creación de la historia inicial
 *  - la construcción del agregado {@link Partida}
 *
 * Package-private.
 */
final class FlujoCrearPartida {

    private FlujoCrearPartida() {}

    static Partida crear(
            int nivelBaseItems,
            int numeroTotalCapitulos,
            int numItemsPorTipoVillano,
            int pvMaxVillano,
            int experienciaVillano,
            int numeroEventosCapitulo,
            int numeroHeroes,
            int numArmasHeroe,
            int numEscudosHeroe,
            int numPocionesHeroe,
            int pvMaxHeroe,
            int experienciaHeroe 
    ) {
        if (numeroHeroes < 1) {
            throw new IllegalArgumentException("El número de héroes debe ser al menos 1.");
        }

        // 1. Contexto de creación
        ContextoCreacion ctx = new ContextoCreacion(nivelBaseItems);

        // 2. Crear héroes con equipamiento configurable
        List<Criatura> heroes = FlujoHeroesCreacion.crearHeroesAutomaticos(
                ctx,
                numeroHeroes,
                numArmasHeroe,
                numEscudosHeroe,
                numPocionesHeroe,
                pvMaxHeroe,
                experienciaHeroe 
        );

        // 3. Crear la historia inicial
        DTOHistoria dtoHistoria = FlujoCrearHistoria.crear(
                ctx,
                numeroTotalCapitulos,
                numItemsPorTipoVillano,
                pvMaxVillano,
                experienciaVillano,
                numeroEventosCapitulo
        );

        // 4. Reconstruir el agregado Historia
        Historia historia = Historias.crearOReconstruir(
                dtoHistoria.capitulos(),
                dtoHistoria.numeroCapitulos(),
                dtoHistoria.villanoFinal()
        );

        // 5. Crear la Partida con héroes
        return Partidas.crear(historia, heroes);
    }
}
