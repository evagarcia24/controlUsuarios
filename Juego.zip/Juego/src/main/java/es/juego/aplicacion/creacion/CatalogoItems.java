package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.item.Item;
import es.juego.dominio.item.Items;

/**
 * Catálogo consumible de items para un nivel base concreto.
 *
 * Genera listas internas mutables (consumibles) tanto para el nivel dado
 * como para el nivel siguiente.
 *
 * Package-private.
 */
final class CatalogoItems {

    // Nivel base para los items del villano o héroe en creación
	
    @SuppressWarnings("unused")
	private final int nivel;
    private final int nivelSiguiente;

    // Listas consumibles del nivel base
    private final List<Item> armasNivel;
    private final List<Item> escudosNivel;
    private final List<Item> pocionesNivel;

    // Listas consumibles del siguiente nivel
    private final List<Item> armasNivelSiguiente;
    private final List<Item> escudosNivelSiguiente;
    private final List<Item> pocionesNivelSiguiente;

    CatalogoItems(int nivel) {

        this.nivel = nivel;
        this.nivelSiguiente = nivel + 1;

        // Nivel base
        this.armasNivel    = new ArrayList<>(Items.armasPorNivel(nivel));
        this.escudosNivel  = new ArrayList<>(Items.escudosPorNivel(nivel));
        this.pocionesNivel = new ArrayList<>(Items.pocionesPorNivel(nivel));

        // Nivel siguiente
        this.armasNivelSiguiente    = new ArrayList<>(Items.armasPorNivel(nivelSiguiente));
        this.escudosNivelSiguiente  = new ArrayList<>(Items.escudosPorNivel(nivelSiguiente));
        this.pocionesNivelSiguiente = new ArrayList<>(Items.pocionesPorNivel(nivelSiguiente));
    }

    // ==============================
    // Items del nivel base
    // ==============================
    Item tomarArmaNivel()     { return extraer(armasNivel); }
    Item tomarEscudoNivel()   { return extraer(escudosNivel); }
    Item tomarPocionNivel()   { return extraer(pocionesNivel); }

    // ==============================
    // Items del nivel siguiente
    // ==============================
    Item tomarArmaNivelSiguiente()     { return extraer(armasNivelSiguiente); }
    Item tomarEscudoNivelSiguiente()   { return extraer(escudosNivelSiguiente); }
    Item tomarPocionNivelSiguiente()   { return extraer(pocionesNivelSiguiente); }

    // ==============================
    // Lógica de extracción aleatoria
    // ==============================
    private Item extraer(List<Item> lista) {
        if (lista.isEmpty()) return null;
        int idx = (int) (Math.random() * lista.size());
        return lista.remove(idx);
    }
}
