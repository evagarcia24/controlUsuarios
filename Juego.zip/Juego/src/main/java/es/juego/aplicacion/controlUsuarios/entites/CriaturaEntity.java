package es.juego.aplicacion.controlUsuarios.entites;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "TB_CRIATURA")
public class CriaturaEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "USUARIO_ID", nullable = false)
	private UsuarioEntity propietario;

	public CriaturaEntity() {

	}

	public CriaturaEntity(UsuarioEntity propietario) {
		super();
		this.propietario = propietario;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public UsuarioEntity getPropietario() {
		return propietario;
	}

	public void setPropietario(UsuarioEntity propietario) {
		this.propietario = propietario;
	}

}