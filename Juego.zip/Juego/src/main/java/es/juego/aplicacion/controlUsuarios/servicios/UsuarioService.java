package es.juego.aplicacion.controlUsuarios.servicios;

import java.util.List;
import java.util.stream.Collectors;

import es.juego.aplicacion.controlUsuarios.dao.UsuarioDAO;
import es.juego.aplicacion.controlUsuarios.dto.UsuarioDTO;
import es.juego.aplicacion.controlUsuarios.entites.UsuarioEntity;
import es.juego.aplicacion.controlUsuarios.excepciones.BusinessException;
import es.juego.aplicacion.controlUsuarios.excepciones.DaoException;

public class UsuarioService {

    private UsuarioDAO usuarioDAO;

    public UsuarioService(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    public void registrarUsuario(UsuarioDTO dto) throws BusinessException {
        try {
            // Comprobar duplicados
            try {
                usuarioDAO.obtenerPorUsername(dto.getUsername());
                throw new BusinessException("Username ya existe");
            } catch (DaoException ignored) {}
            
            try {
                usuarioDAO.obtenerPorEmail(dto.getEmail());
                throw new BusinessException("Email ya existe");
            } catch (DaoException ignored) {}
            
            // Crear entidad
            UsuarioEntity usuario = new UsuarioEntity(
                dto.getUsername(),
                dto.getEmail(),
                dto.getPassword(),
                dto.getRol(),
                dto.isActivo(),
                dto.getImagenPerfil()
            );
            
            usuarioDAO.crearUsuario(usuario);

        } catch (DaoException e) {
            throw new BusinessException("Error al registrar usuario", e);
        }
    }

    public UsuarioEntity login(String usernameOrEmail, String password) throws BusinessException {
        try {
            UsuarioEntity usuario;
            try {
                usuario = usuarioDAO.obtenerPorUsername(usernameOrEmail);
            } catch (DaoException e) {
                usuario = usuarioDAO.obtenerPorEmail(usernameOrEmail);
            }

            if (!usuario.isActivo()) {
                throw new BusinessException("Usuario inactivo");
            }

            if (!usuario.getPassword().equals(password)) {
                throw new BusinessException("Contraseña incorrecta");
            }

            return usuario;

        } catch (DaoException e) {
            throw new BusinessException("Usuario no encontrado");
        }
    }

    public List<UsuarioDTO> listarUsuarios() throws BusinessException {
        try {
            return usuarioDAO.listarUsuarios()
                .stream()
                .map(u -> {
                    UsuarioDTO dto = new UsuarioDTO();
                    dto.setUsername(u.getUsername());
                    dto.setEmail(u.getEmail());
                    dto.setRol(u.getRol());
                    dto.setActivo(u.isActivo());
                    dto.setImagenPerfil(u.getImagenPerfil());
                    return dto;
                })
                .collect(Collectors.toList());
        } catch (DaoException e) {
            throw new BusinessException("Error al listar usuarios", e);
        }
    }

    public void activarUsuario(String username) throws BusinessException {
        try {
            UsuarioEntity usuario = usuarioDAO.obtenerPorUsername(username);
            usuario.setActivo(true);
            usuarioDAO.actualizarUsuario(usuario);
        } catch (DaoException e) {
            throw new BusinessException("Error al activar usuario", e);
        }
    }

    public void desactivarUsuario(String username) throws BusinessException {
        try {
            UsuarioEntity usuario = usuarioDAO.obtenerPorUsername(username);
            usuario.setActivo(false);
            usuarioDAO.actualizarUsuario(usuario);
        } catch (DaoException e) {
            throw new BusinessException("Error al desactivar usuario", e);
        }
    }
}
