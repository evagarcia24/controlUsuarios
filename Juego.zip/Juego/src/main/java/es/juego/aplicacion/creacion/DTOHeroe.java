package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

/**
 * DTO de aplicación para transportar todos los datos necesarios
 * para construir un héroe en el dominio.
 *
 * Package-private.
 */
record DTOHeroe(
        String nombre,
        Raza raza,
        int experiencia,
        int puntosVidaMax,
        List<Item> armas,
        List<Item> escudos,
        List<Item> pociones,
        List<Item> inventarioPasivoArmas,
        List<Item> inventarioPasivoEscudos,
        List<Item> inventarioPasivoPociones
) {}
