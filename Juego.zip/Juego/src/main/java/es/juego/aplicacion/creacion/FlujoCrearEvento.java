package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.Eventos;
import es.juego.dominio.evento.TematicaEventos;

final class FlujoCrearEvento {

    private FlujoCrearEvento() {}

    static DTOEventos crear(TematicaEventos tematica, int cuantos) {

        List<Evento> todos = new ArrayList<>(Eventos.eventosTodos(tematica));
        Collections.shuffle(todos);

        if (cuantos < 1) {
            throw new IllegalArgumentException("Se requiere al menos 1 evento.");
        }
        if (cuantos > todos.size()) {
            throw new IllegalArgumentException(
                "La temática " + tematica +
                " solo tiene " + todos.size() +
                " eventos disponibles, pero se pidieron " + cuantos
            );
        }

        List<Evento> seleccion = new ArrayList<>(todos.subList(0, cuantos));

        return new DTOEventos(seleccion);
    }
}
