// UsuarioDAO.java
package es.juego.aplicacion.controlUsuarios.dao;

import java.util.List;
import es.juego.aplicacion.controlUsuarios.entites.UsuarioEntity;
import es.juego.aplicacion.controlUsuarios.excepciones.DaoException;

public interface UsuarioDAO {
	
    void crearUsuario(UsuarioEntity usuario) throws DaoException;
    UsuarioEntity obtenerPorUsername(String username) throws DaoException;
    UsuarioEntity obtenerPorEmail(String email) throws DaoException;
    List<UsuarioEntity> listarUsuarios() throws DaoException;
    void actualizarUsuario(UsuarioEntity usuario) throws DaoException;
}
