package es.juego.aplicacion.controlUsuarios;

public enum RolUsuario {
	ADMINISTRADOR,
    JUGADOR
}
