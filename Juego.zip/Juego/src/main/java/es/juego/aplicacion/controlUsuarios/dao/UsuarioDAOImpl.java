package es.juego.aplicacion.controlUsuarios.dao;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import es.juego.aplicacion.controlUsuarios.entites.UsuarioEntity;
import es.juego.aplicacion.controlUsuarios.excepciones.DaoException;

public class UsuarioDAOImpl implements UsuarioDAO {

    private EntityManager em;

    public UsuarioDAOImpl(EntityManager em) {
        this.em = em;
    }

    @Override
    public void crearUsuario(UsuarioEntity usuario) throws DaoException {
        try {
            em.getTransaction().begin();
            em.persist(usuario);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw new DaoException("Error al crear usuario", e);
        }
    }

    @Override
    public UsuarioEntity obtenerPorUsername(String username) throws DaoException {
        try {
            TypedQuery<UsuarioEntity> query = em.createQuery(
                "SELECT u FROM UsuarioEntity u WHERE u.username = :username", UsuarioEntity.class);
            query.setParameter("username", username);
            return query.getSingleResult();
        } catch (Exception e) {
            throw new DaoException("Usuario no encontrado", e);
        }
    }

    @Override
    public UsuarioEntity obtenerPorEmail(String email) throws DaoException {
        try {
            TypedQuery<UsuarioEntity> query = em.createQuery(
                "SELECT u FROM UsuarioEntity u WHERE u.email = :email", UsuarioEntity.class);
            query.setParameter("email", email);
            return query.getSingleResult();
        } catch (Exception e) {
            throw new DaoException("Usuario no encontrado", e);
        }
    }

    @Override
    public List<UsuarioEntity> listarUsuarios() throws DaoException {
        try {
            TypedQuery<UsuarioEntity> query = em.createQuery("SELECT u FROM UsuarioEntity u", UsuarioEntity.class);
            return query.getResultList();
        } catch (Exception e) {
            throw new DaoException("Error al listar usuarios", e);
        }
    }

    @Override
    public void actualizarUsuario(UsuarioEntity usuario) throws DaoException {
        try {
            em.getTransaction().begin();
            em.merge(usuario);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw new DaoException("Error al actualizar usuario", e);
        }
    }
}
