package es.juego.aplicacion.partida;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;
import es.juego.dominio.historia.Historias;

/**
 * Estado mutable del progreso narrativo durante una partida.
 *
 * Esta clase no pertenece al dominio. Es un detalle interno de la capa
 * de aplicación encargado de:
 *  - mantener el capítulo actual,
 *  - almacenar la historia parcial,
 *  - añadir nuevos capítulos a medida que se generan,
 *  - fijar el villano final cuando corresponda.
 *
 * El agregado Historia es siempre inmutable. Cada modificación crea
 * una nueva instancia válida a través de la fachada Historias.
 *
 * Esta clase es package-private porque su uso se restringe al paquete
 * de partida y no debe ser expuesta a capas externas.
 */
final class EstadoHistoria {

    private Historia historiaActual;
    private int indiceCapituloActual;

    EstadoHistoria(Historia historiaInicial) {
        if (historiaInicial == null)
            throw new IllegalArgumentException("historiaInicial no puede ser null.");

        this.historiaActual = historiaInicial;
        this.indiceCapituloActual = 0;
    }

    Historia getHistoria() {
        return historiaActual;
    }

    int getIndiceCapituloActual() {
        return indiceCapituloActual;
    }

    Capitulo getCapituloActual() {
        return historiaActual.getCapitulos().get(indiceCapituloActual);
    }

    boolean estaCompletada() {
        return indiceCapituloActual >= historiaActual.getNumeroCapitulos() - 1;
    }

    /**
     * Avanza al siguiente capítulo, reconstruyendo la historia con un capítulo más.
     */
    void avanzar(Capitulo nuevoCapitulo) {
        if (estaCompletada())
            throw new IllegalStateException("La historia ya está completa; no se puede avanzar más.");

        if (nuevoCapitulo == null)
            throw new IllegalArgumentException("nuevoCapitulo no puede ser null.");

        List<Capitulo> nuevos = new ArrayList<>(historiaActual.getCapitulos());
        nuevos.add(nuevoCapitulo);

        this.historiaActual = Historias.crearOReconstruir(
                nuevos,
                historiaActual.getNumeroCapitulos(),
                historiaActual.getVillanoFinalDeHistoria()
        );

        indiceCapituloActual++;
    }

    /**
     * Asigna el villano final de la historia mediante reconstrucción
     * de la Historia del dominio.
     */
    void fijarVillanoFinal(Criatura villanoFinal) {
        if (villanoFinal == null)
            throw new IllegalArgumentException("villanoFinal no puede ser null.");

        this.historiaActual = Historias.crearOReconstruir(
                historiaActual.getCapitulos(),
                historiaActual.getNumeroCapitulos(),
                villanoFinal
        );
    }
}
