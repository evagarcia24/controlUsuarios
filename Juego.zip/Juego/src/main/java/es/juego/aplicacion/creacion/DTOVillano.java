package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

/**
 * DTO con todos los datos necesarios para construir posteriormente
 * una CriaturaVillano dentro de un capítulo.
 *
 * Package-private.
 */
record DTOVillano(
        String nombre,
        Raza raza,
        List<Item> armas,
        List<Item> escudos,
        List<Item> pociones,
        int pvMax,
        int experiencia,
        List<Item> inventarioPasivoArmas,
        List<Item> inventarioPasivoEscudos,
        List<Item> inventarioPasivoPociones
) {}
