package es.juego.aplicacion.creacion;

import es.juego.dominio.evento.TematicaEventos;

/**
 * Traductor TematicaEventos → categoría textual usada por
 * catálogos de nombres y razas de villano.
 *
 * Package-private.
 */
final class CategoriaVillano {

    private CategoriaVillano() {}

    static String de(TematicaEventos t) {
        return switch (t) {
            case BUROCRACIA_DISFUNCIONAL      -> "BURO";
            case CORRUPCION_Y_ESCANDALOS      -> "CORR";
            case INSTITUCIONES_DEFORMADAS     -> "INST";
            case ECONOMIA_Y_CRISIS            -> "ECON";
            case MEDIOS_Y_COMUNICACION        -> "MEDI";
            case INFRAESTRUCTURAS_DEFICIENTES -> "INFR";
            case IDEOLOGIA_Y_TENSIONES        -> "IDEO";
            case SERVICIOS_PUBLICOS_COLAPSADOS -> "SERV";
        };
    }
}
