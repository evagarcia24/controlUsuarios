package es.juego.aplicacion.creacion;

import java.util.List;
import es.juego.dominio.item.Item;

/**
 * DTO para listar los ítems disponibles para los eventos,
 * diferenciando nivel actual y superior.
 *
 * Package-private.
 */
record TBDDTOItems(
        List<Item> itemsNivelActual,
        List<Item> itemsNivelSuperior
) {}
