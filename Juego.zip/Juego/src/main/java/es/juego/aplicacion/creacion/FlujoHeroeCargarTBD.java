package es.juego.aplicacion.creacion;

/**
 * Stub para el flujo de carga de héroes desde memoria/persistencia.
 *
 * De momento solo lanza una excepción para indicar que
 * está pendiente de implementar.
 *
 * Package-private.
 */
final class FlujoHeroeCargarTBD {

    private FlujoHeroeCargarTBD() {}

    static DTOHeroe cargarHeroeDesdeMemoria() {
        throw new UnsupportedOperationException(
                "Flujo de CARGA de héroes desde memoria pendiente de implementar (TBD).");
    }
}
