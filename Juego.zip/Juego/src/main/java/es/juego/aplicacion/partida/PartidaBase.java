package es.juego.aplicacion.partida;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;

/**
 * Implementación interna y mutable de una partida.
 *
 * No se expone fuera del paquete; la interfaz pública es Partida.
 * Se gestiona mediante la fachada Partidas.
 */
final class PartidaBase implements Partida {

    private final List<Jugador> jugadores = new ArrayList<>();
    private final List<Criatura> heroes;
    private EstadoHistoria estadoHistoria;

    PartidaBase(Historia historiaInicial, List<Criatura> heroesIniciales) {
        if (historiaInicial == null)
            throw new IllegalArgumentException("historiaInicial no puede ser null.");
        if (heroesIniciales == null)
            throw new IllegalArgumentException("La lista de héroes no puede ser null.");

        this.estadoHistoria = new EstadoHistoria(historiaInicial);
        this.heroes = new ArrayList<>(heroesIniciales);
    }

    // ===========================
    // Lectura expuesta hacia fuera
    // ===========================

    @Override
    public List<Jugador> getJugadores() {
        return Collections.unmodifiableList(jugadores);
    }

    @Override
    public List<Criatura> getHeroes() {
        return Collections.unmodifiableList(heroes);
    }
    
    @Override
    public Historia getHistoria() {
        return estadoHistoria.getHistoria();
    }

    @Override
    public Capitulo getCapituloActual() {
        return estadoHistoria.getCapituloActual();
    }

    @Override
    public Criatura getVillanoFinal() {
        return estadoHistoria.getHistoria().getVillanoFinalDeHistoria();
    }

    @Override
    public boolean historiaCompleta() {
        return estadoHistoria.estaCompletada()
               && getVillanoFinal() != null;
    }

    // ===========================
    // Métodos internos (package-private)
    // ===========================

    void agregarJugador(Jugador j) {
        if (j != null) {
            jugadores.add(j);
        }
    }

    /**
     * Asigna en bloque una lista de jugadores.
     * Pensado para futuros flujos (por ahora no se usa).
     */
    void asignarJugadores(List<Jugador> nuevos) {
        if (nuevos != null && !nuevos.isEmpty()) {
            jugadores.addAll(nuevos);
        }
    }

    EstadoHistoria getEstadoHistoria() {
        return estadoHistoria;
    }

    void actualizarEstadoHistoria(EstadoHistoria est) {
        if (est != null) {
            this.estadoHistoria = est;
        }
    }
}
