package es.juego.aplicacion.creacion;

import es.juego.aplicacion.partida.Partida;

/**
 * Fachada pública del módulo de creación inicial del juego.
 *
 * Proporciona el punto de entrada oficial para construir
 * una partida nueva completamente generada de forma procedural.
 *
 * La lógica interna se mantiene en flujos package-private,
 * preservando la arquitectura limpia.
 */
public final class Creaciones {

    private Creaciones() {}

    /**
     * Crea una partida nueva lista para jugar.
     *
     * @param nivelBaseItems         nivel base para generación de ítems
     * @param numeroTotalCapitulos   cantidad total de capítulos previstos
     * @param numItemsPorTipoVillano ítems por categoría del villano
     * @param pvMaxVillano           puntos de vida máximos del villano
     * @param experienciaVillano     experiencia inicial del villano
     * @param numeroEventosCapitulo  eventos por capítulo
     * @param numeroHeroes           número de héroes a crear
     *
     * @param numArmasHeroe          armas iniciales por héroe
     * @param numEscudosHeroe        escudos iniciales por héroe
     * @param numPocionesHeroe       pociones iniciales por héroe
     * @param pvMaxHeroe             puntos de vida máximos iniciales del héroe
     * @param experienciaHeroe       experiencia inicial del héroe
     */
    public static Partida crearPartidaNueva(
            int nivelBaseItems,
            int numeroTotalCapitulos,
            int numItemsPorTipoVillano,
            int pvMaxVillano,
            int experienciaVillano,
            int numeroEventosCapitulo,
            int numeroHeroes,
            int numArmasHeroe,
            int numEscudosHeroe,
            int numPocionesHeroe,
            int pvMaxHeroe,
            int experienciaHeroe
    ) {
        return FlujoCrearPartida.crear(
                nivelBaseItems,
                numeroTotalCapitulos,
                numItemsPorTipoVillano,
                pvMaxVillano,
                experienciaVillano,
                numeroEventosCapitulo,
                numeroHeroes,
                numArmasHeroe,
                numEscudosHeroe,
                numPocionesHeroe,
                pvMaxHeroe,
                experienciaHeroe
        );
    }
}
