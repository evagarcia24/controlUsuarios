package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.historia.Historia;

/**
 * DTO para transportar los datos de una Partida
 * sin exponer PartidaBase ni su estado interno mutable.
 *
 * Útil para persistencia futura.
 *
 * Package-private.
 */
record TBDDTOPartida(
        List<Criatura> heroes,
        Historia historia
) {}
