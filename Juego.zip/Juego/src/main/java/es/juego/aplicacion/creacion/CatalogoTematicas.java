package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.evento.Eventos;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Catálogo de temáticas narrativas disponibles para el proceso de creación.
 *
 * Durante la construcción:
 *  - Obtiene todas las temáticas desde Eventos.tematicaTodas()
 *  - Las baraja con shuffle
 *  - Las almacena todas en una lista mutable, consumible
 *
 * Luego permite consumirlas una a una con tomarTematica(),
 * siguiendo el patrón de CatalogoNombres y CatalogoRazas.
 */
final class CatalogoTematicas {

    private final List<TematicaEventos> tematicas;

    public CatalogoTematicas() {
        // Obtiene todas las temáticas disponibles
        List<TematicaEventos> todas = new ArrayList<>(Eventos.tematicaTodas());
        Collections.shuffle(todas);

        // Guardamos TODAS en una lista mutable consumible
        this.tematicas = new ArrayList<>(todas);
    }

    /**
     * Consume y devuelve una temática aleatoria del catálogo.
     * Tras devolverla, desaparece de la lista interna.
     */
    public TematicaEventos tomarTematica() {
        if (tematicas.isEmpty()) {
            return null;
        }

        int idx = (int) (Math.random() * tematicas.size());
        return tematicas.remove(idx);
    }
}
