package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Flujo responsable de generar los datos necesarios
 * para construir la Historia inicial.
 *
 * Devuelve un DTOHistoria. La conversión a dominio la realiza
 * FlujoCrearPartida (o cualquier orquestador superior).
 *
 * Package-private.
 */
final class FlujoCrearHistoria {

    private FlujoCrearHistoria() {}

    static DTOHistoria crear(
            ContextoCreacion ctx,
            int numeroTotalCapitulos,
            int numItemsPorTipoVillano,
            int pvMaxVillano,
            int experienciaVillano,
            int numeroEventosCapitulo
    ) {

        if (numeroTotalCapitulos <= 0)
            throw new IllegalArgumentException("La historia debe tener al menos un capítulo.");

        if (numeroEventosCapitulo <= 0)
            throw new IllegalArgumentException("Cada capítulo debe tener al menos un evento.");

        // 1. Obtener la primera temática
        TematicaEventos tematica = ctx.tematica();
        if (tematica == null)
            throw new IllegalStateException("No quedan temáticas disponibles.");

        // 2. Crear el primer capítulo
        DTOCapitulo dtoCap = FlujoCrearCapitulo.crear(
                tematica,
                ctx,
                numItemsPorTipoVillano,
                pvMaxVillano,
                experienciaVillano,
                numeroEventosCapitulo
        );

        Capitulo primerCapitulo = dtoCap.capitulo();

        // 3. Crear DTOHistoria inicial
        List<Capitulo> capitulos = new ArrayList<>();
        capitulos.add(primerCapitulo);

        return new DTOHistoria(
                capitulos,
                numeroTotalCapitulos,
                null // villano final todavía no asignado
        );
    }
}
