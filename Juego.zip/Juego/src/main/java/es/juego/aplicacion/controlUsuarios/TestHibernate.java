package es.juego.aplicacion.controlUsuarios;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestHibernate {

    public static void main(String[] args) {
        // 1️⃣ Crear la configuración de Hibernate
        Configuration configuration = new Configuration();
        configuration.configure(); // Hibernate busca automáticamente hibernate.cfg.xml en src/main/resources

        // 2️⃣ Construir el SessionFactory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // 3️⃣ Abrir una sesión
        Session session = sessionFactory.openSession();

        // 4️⃣ Iniciar transacción
        session.beginTransaction();

        // 5️⃣ (Opcional) Crear un registro de prueba
        // Descomenta si quieres probar la inserción
        /*
        Usuario u = new Usuario();
        u.setNombre("Juan");
        u.setEmail("juan@correo.com");
        session.save(u);
        */

        // 6️⃣ Commit de la transacción
        session.getTransaction().commit();

        // 7️⃣ Cerrar sesión y SessionFactory
        session.close();
        sessionFactory.close();

        System.out.println("¡TestHibernate ejecutado! Revisa la base de datos para ver las tablas creadas.");
    }
}

