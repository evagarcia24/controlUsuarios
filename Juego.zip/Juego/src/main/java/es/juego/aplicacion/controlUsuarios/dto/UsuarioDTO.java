package es.juego.aplicacion.controlUsuarios.dto;

import es.juego.aplicacion.controlUsuarios.RolUsuario;

public class UsuarioDTO {

	private String username;
	private String email;
	private String password;
	private RolUsuario rol;
	private boolean activo;
	private String imagenPerfil;

	public UsuarioDTO() {
		super();
	}

	public UsuarioDTO(String username, String email, String password, RolUsuario rol, boolean activo,
			String imagenPerfil) {
		super();
		this.username = username;
		this.email = email;
		this.password = password;
		this.rol = rol;
		this.activo = activo;
		this.imagenPerfil = imagenPerfil;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public RolUsuario getRol() {
		return rol;
	}

	public void setRol(RolUsuario rol) {
		this.rol = rol;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	public String getImagenPerfil() {
		return imagenPerfil;
	}

	public void setImagenPerfil(String imagenPerfil) {
		this.imagenPerfil = imagenPerfil;
	}

}
