package es.juego.aplicacion.partida;

/**
 * Representa un jugador dentro de la Partida.
 *
 * Actualmente no contiene lógica relevante,
 * pero se ampliará en el futuro (inventario, grupo, perfil, etc.).
 */
public final class Jugador {

//TODO
}
