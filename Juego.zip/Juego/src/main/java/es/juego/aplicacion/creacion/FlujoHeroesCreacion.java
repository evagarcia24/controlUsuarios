package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.criatura.Criaturas;
import es.juego.dominio.item.Item;

final class FlujoHeroesCreacion {

    private FlujoHeroesCreacion() {}

    static List<Criatura> crearHeroesAutomaticos(
            ContextoCreacion ctx,
            int numeroHeroes,
            int numArmas,
            int numEscudos,
            int numPociones,
            int pvMaxHeroe,
            int experienciaHeroe
    ) {
        if (numeroHeroes < 1)
            throw new IllegalArgumentException("El número de héroes debe ser al menos 1.");

        List<Criatura> resultado = new ArrayList<>(numeroHeroes);

        for (int i = 0; i < numeroHeroes; i++) {

            DTOHeroe dto = FlujoHeroeCrearAuto.crearHeroeAutomatico(
                    ctx,
                    numArmas,
                    numEscudos,
                    numPociones,
                    pvMaxHeroe,
                    experienciaHeroe,
                    new ArrayList<Item>(), // inventario pasivo armas
                    new ArrayList<Item>(), // inventario pasivo escudos
                    new ArrayList<Item>()  // inventario pasivo pociones
            );

            Criatura heroe = Criaturas.crear(
                    dto.nombre(),
                    dto.experiencia(),
                    dto.raza(),
                    dto.puntosVidaMax(),
                    dto.puntosVidaMax(),
                    dto.armas(),
                    dto.escudos(),
                    dto.pociones(),
                    dto.inventarioPasivoArmas(),
                    dto.inventarioPasivoEscudos(),
                    dto.inventarioPasivoPociones()
            );

            resultado.add(heroe);
        }

        return resultado;
    }

}
