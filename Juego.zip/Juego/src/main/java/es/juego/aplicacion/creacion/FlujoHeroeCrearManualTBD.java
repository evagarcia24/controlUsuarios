package es.juego.aplicacion.creacion;

/**
 * Stub para el flujo de creación manual de héroes.
 *
 * De momento solo lanza una excepción para indicar que
 * está pendiente de implementar.
 *
 * Package-private.
 */
final class FlujoHeroeCrearManualTBD {

    private FlujoHeroeCrearManualTBD() {}

    static DTOHeroe crearHeroeManual(ContextoCreacion ctx) {
        throw new UnsupportedOperationException(
                "Flujo de creación MANUAL de héroes pendiente de implementar (TBD).");
    }
}
