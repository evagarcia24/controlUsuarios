package es.juego.aplicacion.controlUsuarios.excepciones;

public class DaoException extends Exception {
    public DaoException(String message, Throwable cause) {
        super(message, cause);
    }
}
