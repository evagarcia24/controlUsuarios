package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

final class FlujoHeroeCrearAuto {

    private FlujoHeroeCrearAuto() {}

    static DTOHeroe crearHeroeAutomatico(
            ContextoCreacion ctx,
            int numArmas,
            int numEscudos,
            int numPociones,
            int pvMaxHeroe,
            int experienciaHeroe,
            ArrayList<Item> inventarioPasivoArmas,
            ArrayList<Item> inventarioPasivoEscudos,
            ArrayList<Item> inventarioPasivoPociones
    ) {

        String nombre = ctx.nombreHeroe();
        Raza raza     = ctx.razaHeroe();
        
        int experiencia = experienciaHeroe;
        int pvMax       = pvMaxHeroe;

        // ================================
        // Construcción de equipamiento
        // ================================
        List<Item> armas    = new ArrayList<>();
        List<Item> escudos  = new ArrayList<>();
        List<Item> pociones = new ArrayList<>();

        for (int i = 0; i < numArmas; i++) {
            Item it = ctx.armaNivel();
            if (it != null) armas.add(it);
        }

        for (int i = 0; i < numEscudos; i++) {
            Item it = ctx.escudoNivel();
            if (it != null) escudos.add(it);
        }

        for (int i = 0; i < numPociones; i++) {
            Item it = ctx.pocionNivel();
            if (it != null) pociones.add(it);
        }

        return new DTOHeroe(
                nombre,
                raza,
                experiencia,
                pvMax,
                armas,
                escudos,
                pociones,
                new ArrayList<Item>(), // inventario pasivo armas
                new ArrayList<Item>(), // inventario pasivo escudos
                new ArrayList<Item>()  // inventario pasivo pociones
        );
    }
}

