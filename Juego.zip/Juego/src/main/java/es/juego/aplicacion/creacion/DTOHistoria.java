package es.juego.aplicacion.creacion;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;

/**
 * DTO que contiene los datos necesarios para construir
 * una Historia mediante la fachada del dominio.
 *
 * Package-private.
 */
record DTOHistoria(
        List<Capitulo> capitulos,
        int numeroCapitulos,
        Criatura villanoFinal
) {}
