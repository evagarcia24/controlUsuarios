package es.juego.aplicacion.creacion;

import es.juego.dominio.evento.TematicaEventos;
import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

/**
 * Contexto único para la fase de creación inicial de la partida.
 *
 * Contiene catálogos consumibles de nombres, razas e items.
 * No gestiona niveles dinámicos ni progresión.
 *
 * Package-private: solo accesible desde flujos del paquete creacion.
 */
final class ContextoCreacion {

    private final CatalogoNombres catalogoNombres;
    private final CatalogoRazas catalogoRazas;
    private final CatalogoItems catalogoItems;
    private final CatalogoTematicas catalogoTematicas;

    ContextoCreacion(int nivel) {
        this.catalogoNombres   = new CatalogoNombres();
        this.catalogoRazas     = new CatalogoRazas();
        this.catalogoItems     = new CatalogoItems(nivel);
        this.catalogoTematicas = new CatalogoTematicas();
    }

    // ==============================
    // Nombres
    // ==============================
    String nombreHeroe() {
        return catalogoNombres.tomarNombreHeroe();
    }

    String nombreVillano(String categoria) {
        return catalogoNombres.tomarNombreVillano(categoria);
    }

    // ==============================
    // Razas
    // ==============================
    Raza razaHeroe() {
        return catalogoRazas.tomarRazaHeroe();
    }

    Raza razaVillano(String categoria) {
        return catalogoRazas.tomarRazaVillano(categoria);
    }

    // ==============================
    // Ítems del nivel actual
    // ==============================
    Item armaNivel()     { return catalogoItems.tomarArmaNivel(); }
    Item escudoNivel()   { return catalogoItems.tomarEscudoNivel(); }
    Item pocionNivel()   { return catalogoItems.tomarPocionNivel(); }

    // ==============================
    // Ítems del nivel siguiente
    // ==============================
    Item armaNivelSiguiente()     { return catalogoItems.tomarArmaNivelSiguiente(); }
    Item escudoNivelSiguiente()   { return catalogoItems.tomarEscudoNivelSiguiente(); }
    Item pocionNivelSiguiente()   { return catalogoItems.tomarPocionNivelSiguiente(); }

    // ==============================
    // Temáticas
    // ==============================
    TematicaEventos tematica() {
        return catalogoTematicas.tomarTematica();
    }
}
