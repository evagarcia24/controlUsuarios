package es.juego.aplicacion.creacion;

import java.util.List;
import es.juego.dominio.evento.Evento;

/**
 * DTO que transporta una lista de eventos generados
 * para una temática concreta.
 *
 * Package-private.
 */
record DTOEventos(List<Evento> eventos) {}
