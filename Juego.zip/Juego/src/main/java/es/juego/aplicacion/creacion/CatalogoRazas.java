package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import es.juego.dominio.raza.Raza;
import es.juego.dominio.raza.Razas;

final class CatalogoRazas {

    private final List<Raza> razasHeroe;
    private final Map<String, List<Raza>> razasVillano;

    CatalogoRazas() {
        this.razasHeroe   = new ArrayList<>(Razas.todasLasRazasHeroe());
        this.razasVillano = Razas.razasVillanoPorCategoria();
    }

    // =====================================
    // Héroes
    // =====================================

    Raza tomarRazaHeroe() {
        if (razasHeroe == null || razasHeroe.isEmpty()) {
            return null;
        }
        int idx = (int)(Math.random() * razasHeroe.size());
        return razasHeroe.remove(idx);
    }

    // =====================================
    // Villanos
    // =====================================

    Raza tomarRazaVillano(String categoria) {
        List<Raza> lista = razasVillano.get(categoria);
        if (lista == null || lista.isEmpty()) {
            return null;
        }
        int idx = (int)(Math.random() * lista.size());
        return lista.remove(idx);
    }
}
