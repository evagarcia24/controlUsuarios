package es.juego.aplicacion.creacion;

import es.juego.dominio.capitulo.Capitulo;

/**
 * DTO que transporta el capítulo generado en esta fase.
 * Package-private.
 */
record DTOCapitulo(Capitulo capitulo) {}
