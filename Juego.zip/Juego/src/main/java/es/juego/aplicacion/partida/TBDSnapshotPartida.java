package es.juego.aplicacion.partida;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.criatura.Criaturas;

/**
 * Snapshot inmutable del estado visible de una partida en un momento concreto.
 *
 * Esta clase captura una fotografía autosuficiente del estado actual de los
 * héroes y del villano final (si existe), mediante copias profundas realizadas
 * a través de {@link Criaturas#copiar(Criatura)}. El snapshot conserva además
 * un indicador de si la historia completa ya ha finalizado en el instante en
 * que se toma la captura.
 *
 * La instancia generada es completamente independiente del estado vivo de la
 * partida; ninguna modificación posterior sobre los héroes o el villano
 * afectará al contenido del snapshot. Todas las colecciones son inmutables y
 * el objeto es íntegramente de solo lectura.
 *
 * Esta clase no forma parte del dominio. Es un detalle interno de la capa de
 * aplicación destinado a análisis, registro, depuración o persistencia no
 * interactiva. Puede ampliarse en el futuro para capturar información adicional
 * según evolucionen los requisitos de guardado o diagnóstico.
 */

final class TBDSnapshotPartida {

    private final List<Criatura> heroesCopia;
    private final Criatura villanoCopia;
    private final boolean historiaCompletada;

    TBDSnapshotPartida(Partida partida) {
        if (partida == null)
            throw new IllegalArgumentException("partida no puede ser null.");

        // Copia profunda de héroes
        List<Criatura> origen = partida.getHeroes();
        List<Criatura> copiaH = new ArrayList<>();

        for (int i = 0; i < origen.size(); i++) {
            copiaH.add(Criaturas.copiar(origen.get(i)));
        }

        this.heroesCopia = Collections.unmodifiableList(copiaH);

        // Copia profunda del villano, si existe
        Criatura villano = partida.getVillanoFinal();
        this.villanoCopia = (villano != null ? Criaturas.copiar(villano) : null);

        // Datos auxiliares del snapshot
        this.historiaCompletada = partida.historiaCompleta();
    }

    List<Criatura> getHeroes() {
        return heroesCopia;
    }

    Criatura getVillano() {
        return villanoCopia;
    }

    boolean isHistoriaCompletada() {
        return historiaCompletada;
    }
}
