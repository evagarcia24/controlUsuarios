package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;

import es.juego.dominio.evento.TematicaEventos;
import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

final class FlujoCreacionVillano {

    private FlujoCreacionVillano() {}

    static DTOVillano crear(
            TematicaEventos tematica,
            ContextoCreacion ctx,
            int numItemsPorTipoVillano,
            int pvMax,
            int experiencia
    ) {

    	if (numItemsPorTipoVillano < 0)
            throw new IllegalArgumentException("numItemsPorTipoVillano no puede ser negativo.");

        String categoria = CategoriaVillano.de(tematica);

        String nombre = ctx.nombreVillano(categoria);
        Raza raza     = ctx.razaVillano(categoria);

        List<Item> armas     = new ArrayList<>(numItemsPorTipoVillano);
        List<Item> escudos   = new ArrayList<>(numItemsPorTipoVillano);
        List<Item> pociones  = new ArrayList<>(numItemsPorTipoVillano);

        // El villano utiliza ítems del nivel siguiente
        for (int i = 0; i < numItemsPorTipoVillano; i++) {
            armas.add(ctx.armaNivelSiguiente());
            escudos.add(ctx.escudoNivelSiguiente());
            pociones.add(ctx.pocionNivelSiguiente());
        }

        return new DTOVillano(
                nombre,
                raza,
                armas,
                escudos,
                pociones,
                pvMax,
                experiencia,
                new ArrayList<Item>(), // inventario pasivo armas
                new ArrayList<Item>(), // inventario pasivo escudos
                new ArrayList<Item>()  // inventario pasivo pociones
        );
    }
}
