package es.juego.aplicacion.creacion;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import es.juego.dominio.nombre.Nombres;

final class CatalogoNombres {

    private final List<String> heroes;
    private final Map<String, List<String>> villanos;

    CatalogoNombres() {
        this.heroes  = new ArrayList<>(Nombres.heroes());
        this.villanos = Nombres.villanosPorCategoria();
    }

    String tomarNombreHeroe() {
        int idx = (int)(Math.random() * heroes.size());
        return heroes.remove(idx);
    }

    String tomarNombreVillano(String categoria) {
        List<String> lista = villanos.get(categoria);
        if (lista == null || lista.isEmpty()) return null;
        int idx = (int)(Math.random() * lista.size());
        return lista.remove(idx);
    }
}
