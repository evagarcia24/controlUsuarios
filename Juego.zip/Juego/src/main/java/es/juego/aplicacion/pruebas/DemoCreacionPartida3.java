package es.juego.aplicacion.pruebas;

import java.util.List;

import es.juego.aplicacion.creacion.Creaciones;
import es.juego.aplicacion.partida.Partida;
import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.criatura.Criaturas;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.historia.Historia;
import es.juego.dominio.item.Item;

public final class DemoCreacionPartida3 {

    private DemoCreacionPartida3() {}

    public static void main(String[] args) {

        int nivelBaseItems          = 1;
        int numeroTotalCapitulos    = 3;
        int numItemsPorTipoVillano  = 2;
        int pvMaxVillano            = 50;
        int experienciaVillano      = 10;
        int numeroEventosCapitulo   = 3;
        int numeroHeroes            = 3;

        int numArmasHeroe    = 1;
        int numEscudosHeroe  = 1;
        int numPocionesHeroe = 1;
        int pvMaxHeroe       = 30;
        int experienciaHeroe = 1;

        Partida partida = Creaciones.crearPartidaNueva(
                nivelBaseItems,
                numeroTotalCapitulos,
                numItemsPorTipoVillano,
                pvMaxVillano,
                experienciaVillano,
                numeroEventosCapitulo,
                numeroHeroes,
                numArmasHeroe,
                numEscudosHeroe,
                numPocionesHeroe,
                pvMaxHeroe,
                experienciaHeroe
        );

        Historia historia = partida.getHistoria();

        System.out.println("===== RESUMEN DE LA PARTIDA =====\n");

        // ======================
        // HÉROES
        // ======================
        System.out.println("Héroes creados:");
        List<Criatura> heroes = partida.getHeroes();
        int idx = 1;

        for (Criatura h : heroes) {
            System.out.println("  Héroe " + idx + ": " + h.getNombre());
            System.out.println("    Raza:        " + h.getRaza().getTipo());
            System.out.println("    PV:          " + h.getPuntosVida() + "/" + h.getPuntosVidaMax());
            System.out.println("    Experiencia: " + h.getExperiencia());

            System.out.println("    Armas:");
            imprimirItems(h.getArmas());

            System.out.println("    Escudos:");
            imprimirItems(h.getEscudos());

            System.out.println("    Pociones:");
            imprimirItems(h.getPociones());

            System.out.println();
            idx++;
        }

        // ======================
        // HISTORIA
        // ======================
        System.out.println("Capítulos previstos en la historia: "
                + historia.getNumeroCapitulos());
        System.out.println();

        // ======================
        // CAPÍTULO ACTUAL
        // ======================
        Capitulo capituloActual = partida.getCapituloActual();

        System.out.println("Temática del capítulo actual: "
                + capituloActual.getTematica() + "\n");

        System.out.println("Eventos del capítulo actual:");
        int i = 1;
        for (Evento e : capituloActual.getEventos()) {
            System.out.println("  " + i + ". " + e.getTitulo());
            i++;
        }
        System.out.println();

        // ======================
        // VILLANO DEL CAPÍTULO
        // ======================
        Criatura villano = capituloActual.getVillano();

        System.out.println("Villano del capítulo actual:");
        System.out.println("  Nombre:      " + villano.getNombre());
        System.out.println("  Raza:        " + villano.getRaza().getTipo());
        System.out.println("  Puntos vida: "
                + villano.getPuntosVida() + "/" + villano.getPuntosVidaMax());
        System.out.println("  Experiencia: " + villano.getExperiencia());
        System.out.println();

        System.out.println("  Armas del villano:");
        imprimirItems(villano.getArmas());

        System.out.println("  Escudos del villano:");
        imprimirItems(villano.getEscudos());

        System.out.println("  Pociones del villano:");
        imprimirItems(villano.getPociones());

        // ============================================================
        //  NUEVA PRUEBA: APLICAR UNA POCIÓN A UN HÉROE
        // ============================================================

        System.out.println("\n===== PRUEBA DE APLICACIÓN DE POCIONES =====");

        if (!heroes.isEmpty()) {

            Criatura heroe = heroes.get(0);

            System.out.println("\nHéroe seleccionado: " + heroe.getNombre());
            System.out.println("PV inicial: " + heroe.getPuntosVida());

            List<Item> pociones = heroe.getPociones();

            if (pociones.isEmpty()) {
                System.out.println("El héroe no tiene pociones. No se puede probar la curación.");
            } else {

                Item pocion = pociones.get(0);

                System.out.println("Poción seleccionada:");
                System.out.println("  - " + pocion.getNombre() +
                        " (nivel " + pocion.getNivel() +
                        ", puntos " + pocion.getPuntos() + ")");

                System.out.println("\nInventario ACTIVO antes:");
                imprimirItems(heroe.getPociones());

                System.out.println("Inventario PASIVO antes:");
                imprimirItems(heroe.getInventarioPasivoPociones());

                System.out.println("Aplicando poción...\n");

                // === llamada real a la regla de dominio ===
                Criaturas.aplicarPocion(heroe, pocion);

                System.out.println("PV después: " + heroe.getPuntosVida());

                System.out.println("\nInventario ACTIVO después:");
                imprimirItems(heroe.getPociones());

                System.out.println("Inventario PASIVO después:");
                imprimirItems(heroe.getInventarioPasivoPociones());
            }
        }

        System.out.println("===== FIN DE LA PRUEBA =====");
    }

    private static void imprimirItems(List<Item> items) {
        if (items == null || items.isEmpty()) {
            System.out.println("    (ninguno)\n");
            return;
        }
        for (Item it : items) {
            System.out.println("    - " + it.getNombre()
                    + " (nivel " + it.getNivel()
                    + ", puntos " + it.getPuntos() + ")");
        }
        System.out.println();
    }
}
