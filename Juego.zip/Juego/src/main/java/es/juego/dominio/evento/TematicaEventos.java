package es.juego.dominio.evento;

/**
 * Temáticas posibles de eventos narrativos.
 * Expuestas públicamente para que la aplicación elija
 * qué tipo de evento solicitar.
 */
public enum TematicaEventos {
    BUROCRACIA_DISFUNCIONAL,
    CORRUPCION_Y_ESCANDALOS,
    INSTITUCIONES_DEFORMADAS,
    ECONOMIA_Y_CRISIS,
    MEDIOS_Y_COMUNICACION,
    INFRAESTRUCTURAS_DEFICIENTES,
    SERVICIOS_PUBLICOS_COLAPSADOS,
    IDEOLOGIA_Y_TENSIONES
    // Nota: Metafísica y sarcasmo no tiene eventos, solo villanos
}
