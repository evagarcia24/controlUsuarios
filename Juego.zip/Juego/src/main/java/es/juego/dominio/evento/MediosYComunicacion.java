package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum MediosYComunicacion implements EnumEventoNarrativo  {

    RUMOR_VIRAL(
        "Rumor Viral",
        "Un rumor descontrolado se extiende por los pasillos a la velocidad de un rayo, cambiando de forma cada pocos segundos.",

        "Intentar desmentir el rumor",
        "Ignorarlo y seguir andando",

        "El rumor te señala como fuente y un grupo te increpa, causándote un susto doloroso.",
        "El rumor cambia antes de que puedas reaccionar y no te afecta.",
        "Logras desmontar el rumor y alguien te entrega un pequeño obsequio agradecido.",
        "Consigues detener la cadena completa y recibes un impulso vital de claridad."
    ),

    REPORTERO_AGRESIVO(
        "Reportero Agresivo",
        "Un reportero aparece de repente, micro en mano, persiguiéndote para obtener declaraciones sensacionalistas.",

        "Responder al reportero para intentar calmarlo",
        "Esquivar al reportero y cambiar de pasillo",

        "El micrófono te golpea accidentalmente en la frente.",
        "El reportero pierde interés y se va sin más.",
        "Tu respuesta genera simpatía y te regalan un pequeño recurso.",
        "Tu carisma desarma al reportero, que te ofrece una bendición revitalizante."
    ),

    CAMARA_OCULTA(
        "Cámara Oculta",
        "Notas un brillo sospechoso en una esquina y descubres una cámara oculta grabando tus movimientos.",

        "Intentar desactivar la cámara",
        "Ignorarla y alejarte con naturalidad",

        "Te corta un cable suelto que da un pequeño chispazo.",
        "La cámara gira, pero no parece afectar tu camino.",
        "Consigues apagarla y encuentras un objeto útil escondido.",
        "La cámara proyecta un holograma que te inspira y revitaliza."
    ),

    NOTICIA_MANIPULADA(
        "Noticia Manipulada",
        "Una pantalla gigante reproduce una noticia claramente manipulada, cambiando la narrativa en tiempo real.",

        "Intentar corregir la noticia desde la consola",
        "Apagar la pantalla y seguir adelante",

        "Una descarga de la consola te produce un cosquilleo doloroso.",
        "La pantalla se apaga sola sin consecuencias.",
        "Logras ajustar el titular y recibes un pequeño recurso.",
        "Encuentras un modo oculto que te concede un aumento de vitalidad."
    ),

    ENTREVISTA_TRAMPA(
        "Entrevista Trampa",
        "Un presentador aparece súbitamente ofreciéndote una entrevista en directo sin previo aviso.",

        "Participar en la entrevista",
        "Rechazar y retirarte",

        "El presentador insiste y te golpea accidentalmente con el foco.",
        "Te marchas sin que ocurra nada notable.",
        "Tu respuesta improvisada causa furor y recibes una recompensa.",
        "Tu intervención es legendaria y te llena de energía interior."
    ),

    PLATOS_INTERACTIVOS(
        "Platós Interactivos",
        "Pasas junto a varios estudios donde pantallas, focos y cámaras reaccionan a tu presencia como si tuvieran voluntad propia.",

        "Interactuar con el plató",
        "Ignorar el espectáculo y continuar",

        "Un foco cae ligeramente sobre tu hombro.",
        "El plató solo parpadea unos segundos.",
        "Encuentras un objeto útil en una mesa de atrezzo.",
        "El plató se sincroniza contigo y te otorga energía renovada."
    ),

    ANUNCIO_PERSISTENTE(
        "Anuncio Persistente",
        "Un anuncio holográfico te sigue por el pasillo intentando venderte soluciones absurdas a problemas inexistentes.",

        "Intentar cerrar el anuncio desde la interfaz flotante",
        "Caminar más rápido hasta que se canse",

        "La interfaz te lanza un destello que te desorienta un instante.",
        "El anuncio pierde interés y desaparece.",
        "Logras cerrarlo correctamente y encuentras una recompensa escondida.",
        "Al desactivarlo del todo, se desbloquea un modo premium que te revitaliza."
    ),

    RUEDA_DE_PRENSA_CAOTICA(
        "Rueda de Prensa Caótica",
        "Un grupo de portavoces discute entre sí mientras flashes y micrófonos invaden el espacio.",

        "Intentar organizar preguntas para calmar el caos",
        "Apartarte sigilosamente del tumulto",

        "Una cámara se gira de golpe y te golpea el brazo.",
        "El caos sigue, pero no te afecta.",
        "Logras que te entreguen un documento útil.",
        "El caos se ordena momentáneamente y recibes una oleada de vitalidad."
    ),

    TERTULIA_SIN_FIN(
        "Tertulia Sin Fin",
        "Una mesa redonda televisiva debate sobre el mismo asunto desde hace horas sin llegar a ninguna conclusión.",

        "Intervenir para intentar cerrar el debate",
        "Rodear la mesa y seguir tu camino",

        "Un tertuliano manotea y te da un golpe accidental.",
        "La tertulia continúa sin consecuencias para ti.",
        "Tu comentario aporta claridad y recibes un pequeño obsequio.",
        "Tu intervención cierra la tertulia y te llena de energía."
    ),

    PANTALLA_SUPERSATURADA(
        "Pantalla Supersaturada",
        "Una megapanalla muestra tantas noticias simultáneas que se distorsiona y emite un zumbido inquietante.",

        "Intentar estabilizar la emisión",
        "Mirar a otro lado y continuar",

        "La pantalla emite un destello que te hiere ligeramente.",
        "La imagen se corrige sola sin mayor impacto.",
        "Recuperas un accesorio útil del panel técnico.",
        "La pantalla se aclara por completo y te envuelve un flujo revitalizante."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    MediosYComunicacion(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
