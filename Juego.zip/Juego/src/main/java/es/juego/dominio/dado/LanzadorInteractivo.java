package es.juego.dominio.dado;

import java.util.function.IntSupplier;

/**
 * El lanzador interactivo delega en una callback proporcionada por el flujo,
 * que se encargará de obtener la tirada desde consola, web, UI, etc.
 */
final class LanzadorInteractivo implements Lanzador {

    private final IntSupplier callback;

    LanzadorInteractivo(IntSupplier callback) {
        this.callback = callback;
    }

    @Override
    public int lanzar(Caras caras) {
        return callback.getAsInt();
    }
}
