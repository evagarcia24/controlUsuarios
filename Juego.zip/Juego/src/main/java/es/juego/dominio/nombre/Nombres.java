package es.juego.dominio.nombre;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Fachada pública del subdominio de nombres de criaturas.
 *
 * <p>Proporciona acceso de alto nivel a los catálogos internos de nombres
 * de héroes y villanos, manteniendo ocultos los enums y las estructuras
 * internas del paquete. Todo dato expuesto por esta fachada es una copia
 * independiente, de modo que las capas superiores pueden modificarlo sin
 * afectar al dominio.
 *
 * <p>Para héroes se proporciona un catálogo lineal. Para villanos, el
 * catálogo está organizado por categorías temáticas derivadas del nombre
 * del enum.
 */

public final class Nombres {

    private Nombres() {
        // fachada estática, no instanciable
    }

    /**
     * Devuelve una lista mutable con todos los nombres de héroes definidos en el
     * catálogo interno.
     *
     * <p>Los valores proceden de {@code NombreHeroeEnum}, pero no se expone el
     * enum original: solo se devuelven las cadenas de texto asociadas.
     *
     * <p>La lista devuelta es independiente y puede manipularse sin afectar
     * al catálogo real.
     *
     * @return lista de nombres de héroes
     */
    public static List<String> heroes() {

        NombreHeroeEnum[] origen = NombreHeroeEnum.values();
        List<String> lista = new ArrayList<String>(origen.length);

        for (int i = 0; i < origen.length; i++) {
            lista.add(origen[i].getNombre());
        }
        return lista;
    }

    /**
     * Devuelve el catálogo completo de nombres de villanos agrupados por
     * categoría temática.
     *
     * <p>La categoría de cada enum se deriva automáticamente tomando las
     * primeras cuatro letras del identificador de la constante.
     * Ejemplos:
     * <ul>
     *     <li>{@code BUROCRACIA_DISFUNCIONAL} → {@code "BURO"}</li>
     *     <li>{@code CORRUPCION_Y_ESCANDALOS} → {@code "CORR"}</li>
     *     <li>{@code INSTITUCIONES_DEFORMADAS} → {@code "INST"}</li>
     *     <li>{@code ECONOMIA_Y_CRISIS} → {@code "ECON"}</li>
     * </ul>
     *
     * <p>La clave del mapa es la categoría (las primeras 4 letras).
     * El valor es una lista mutable con los nombres asociados a dicha
     * categoría.
     *
     * <p>Ni el mapa ni sus listas están vinculados al catálogo interno:
     * son copias completas que pueden modificarse libremente.
     *
     * @return mapa categoría de 4 letras → lista de nombres de villano
     */
    public static Map<String, List<String>> villanosPorCategoria() {

        NombreVillanoEnum[] origen = NombreVillanoEnum.values();
        Map<String, List<String>> mapa =
                new HashMap<String, List<String>>();

        for (int i = 0; i < origen.length; i++) {

            NombreVillanoEnum e = origen[i];

            String categoria = extraerCategoria4(e.name());

            String[] arr = e.getTipos();
            List<String> lista = new ArrayList<String>(arr.length);

            for (int j = 0; j < arr.length; j++) {
                lista.add(arr[j]);
            }

            mapa.put(categoria, lista);
        }

        return mapa;
    }

    /**
     * Extrae la categoría a partir del nombre del enum de villanos.
     *
     * <p>La categoría se define como las primeras cuatro letras del
     * identificador de la constante. Si el identificador es más corto,
     * se devuelve tal cual.
     *
     * @param nombre nombre completo del enum (por ejemplo, {@code "BUROCRACIA_DISFUNCIONAL"})
     * @return categoría formada por las primeras cuatro letras
     */
    private static String extraerCategoria4(String nombre) {

        if (nombre.length() <= 4) {
            return nombre;
        }
        return nombre.substring(0, 4);
    }
}
