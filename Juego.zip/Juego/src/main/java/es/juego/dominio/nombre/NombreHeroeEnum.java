package es.juego.dominio.nombre;

import lombok.Getter;

@Getter
enum NombreHeroeEnum {

    // A (5)
    AGAPITO("Agapito"),
    ANACLETO("Anacleto"),
    ANICETO("Aniceto"),
    AMBROSIO("Ambrosio"),
    AURELIANO("Aureliano"),

    // B (5)
    BALDOMERO("Baldomero"),
    BARTOLO("Bártolo"),
    BERNABE("Bernabé"),
    BIGOTES("Bigotes"),
    BONIFACIO("Bonifacio"),

    // C (5)
    CANDELARIO("Candelario"),
    CIPRIANO("Cipriano"),
    CIRILO("Cirilo"),
    COSME("Cosme"),
    CUSTODIO("Custodio"),

    // D (5)
    DESIDERIO("Desiderio"),
    DEMETRIO("Demetrio"),
    DOROTEO("Doroteo"),
    DIONISIO_H("Dionisio el Humilde"),
    DONATO("Donato"),

    // E (5)
    EUSEBIO("Eusebio"),
    EUSTAQUIO("Eustaquio"),
    ELIGIO("Eligio"),
    EMERITO("Emérito"),
    EUFRASIO("Eufrasio"),

    // F (5)
    FAUSTINO("Faustino"),
    FERMOSO("Fermoso"),
    FEOTIMO("Feótemo"),
    FIDELON("Fidelón"),
    FLORENCIO("Florencio"),

    // G (5)
    GENARO("Genaro"),
    GERVASIO("Gervasio"),
    GUMERSINDO("Gumersindo"),
    GILBERTO("Gilberto"),
    GABOTAS("Gabotás"),

    // H (5)
    HIGINIO("Higinio"),
    HONORATO("Honorato"),
    HOMOBONO("Homobono"),
    HERMELINDO("Hermelindo"),
    HELIODORO("Heliodoro"),

    // I (5)
    ISIDORIN("Isidorín"),
    ILDEFONSO("Ildefonso"),
    INOCENCIO("Inocencio"),
    INDALECIO("Indalecio"),
    IRINEO("Irineo"),

    // J (5)
    JUSTINO("Justino"),
    JACINTO("Jacinto"),
    JERONIMILLO("Jeronimillo"),
    JUVENAL("Juvenal"),
    JOAQUINOTE("Joaquinote"),

    // L (5)
    LEOPOLDO_H("Leopoldo el Honrado"),
    LINO("Lino"),
    LUPERCO("Luperco"),
    LUPICINIO("Lupicinio"),
    LORITO("Lorito"),

    // M (5)
    MATIAS("Matías"),
    MELCHORIN("Melchorín"),
    MODESTO("Modesto"),
    MOCETON("Mocetón"),
    MAMERTO("Mamerto"),

    // N (5)
    NICASIO("Nicasio"),
    NEMESIO("Nemesio"),
    NARCISIN("Narcisín"),
    NAPOLEONCITO("Napoleoncito"),
    NUBERTO("Nuberto"),

    // O (5)
    ORESTES("Orestes"),
    OLEGARIO("Olegario"),
    OVIDIO("Ovidio"),
    OSCARIN("Oscarín"),
    OSTOLAZO("Ostolazo"),

    // P (5)
    PANCRACIO("Pancracio"),
    PROCOPIO("Procopio"),
    POMPILIO("Pompilio"),
    PASCUALIN("Pascualín"),
    PELAYIN("Pelayín"),

    // R (5)
    RAIMUNDO("Raimundo"),
    REMIGIO("Remigio"),
    RUFINO("Rufino"),
    RODOLFETE("Rodolfete"),
    ROMUALDO("Romualdo"),

    // S (5)
    SATURNINO("Saturnino"),
    SIMEON("Simeón"),
    SEGUNDO("Segundo"),
    SALUSTIANO("Salustiano"),
    SOCORRITO("Socorrito"),

    // T (5)
    TEODORICO("Teodorico"),
    TEOFILO("Teófilo"),
    TRIFON("Trifón"),
    TIMOTEO_H("Timoteo el Sosegado"),
    TOMASON("Tomasón"),

    // U (5)
    URBANO("Urbano"),
    UFRONIO("Ufronio"),
    UBALDINO("Ubaldino"),
    ULISES_H("Ulises el Cortés"),
    UVIDIO("Uvidio"),

    // V (5)
    VENTURA_H("Ventura el Prudente"),
    VALERIANO("Valeriano"),
    VELASCO("Velasco"),
    VICTORIN("Victorín"),
    VIRGILIO("Virgilio");

	private final String nombre;

	NombreHeroeEnum(String nombre) {
		this.nombre = nombre;
    }
}
