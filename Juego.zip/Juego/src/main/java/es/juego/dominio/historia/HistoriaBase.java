package es.juego.dominio.historia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;

/**
 * Implementación interna e inmutable de {@link Historia}.
 *
 * Contiene:
 *  - la lista actual de capítulos generados hasta el momento,
 *  - el número total de capítulos previsto para la historia,
 *  - y el villano final de la historia, que puede ser null mientras
 *    la historia aún está en construcción.
 *
 * Esta clase es parte del agregado de dominio y no expone
 * constructores públicos. No implementa Serializable. La
 * reconstrucción del agregado se realiza exclusivamente
 * mediante {@link HistoriaAssembler} o métodos de la fachada
 * {@link Historias}.
 *
 * Invariantes aplicadas:
 *  - La lista de capítulos no puede ser null ni estar vacía.
 *  - Ningún capítulo de la lista puede ser null.
 *  - numeroCapitulos representa el total previsto y debe ser
 *    mayor o igual que el número de capítulos actualmente generados.
 *  - El villano final de la historia puede ser null durante la fase
 *    inicial de creación. Se fijará posteriormente mediante
 *    los flujos de aplicación cuando corresponda.
 *
 * La instancia es completamente inmutable una vez creada.
 */

final class HistoriaBase implements Historia {

    private final List<Capitulo> capitulos;
    private final int numeroCapitulos;
    private final Criatura villanoFinalDeHistoria;

    HistoriaBase(
            List<Capitulo> capitulos,
            int numeroCapitulos,
            Criatura villanoFinalDeHistoria
    ) {

        if (capitulos == null || capitulos.isEmpty())
            throw new IllegalArgumentException("Una historia debe tener al menos un capítulo.");

        if (capitulos.contains(null))
            throw new IllegalArgumentException("La lista de capítulos contiene valores null.");

        // Cambio clave: total previsto no puede ser menor que los capítulos reales
        if (numeroCapitulos < capitulos.size())
            throw new IllegalArgumentException(
                "numeroCapitulos (" + numeroCapitulos +
                ") no puede ser menor que la cantidad real de capítulos (" +
                capitulos.size() + ")."
            );

        // Cambio clave: el villano final global puede ser null en la fase inicial
        // Se fijará más adelante vía EstadoHistoria.fijarVillanoFinal(...)
        // if (villanoFinalDeHistoria == null)
        //     throw new IllegalArgumentException("La historia debe tener un villano final.");

        this.capitulos = new ArrayList<>(capitulos);
        this.numeroCapitulos = numeroCapitulos;
        this.villanoFinalDeHistoria = villanoFinalDeHistoria;
    }

    @Override
    public List<Capitulo> getCapitulos() {
        return Collections.unmodifiableList(capitulos);
    }

    @Override
    public int getNumeroCapitulos() {
        return numeroCapitulos;
    }

    @Override
    public Criatura getVillanoFinalDeHistoria() {
        return villanoFinalDeHistoria;
    }
}
