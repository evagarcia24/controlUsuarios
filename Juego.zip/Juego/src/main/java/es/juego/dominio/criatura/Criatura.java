package es.juego.dominio.criatura;

import java.util.List;

import es.juego.dominio.item.Item;
import es.juego.dominio.raza.Raza;

public interface Criatura {

	String getNombre();

	int getExperiencia();

	Raza getRaza();

	int getPuntosVida();

	int getPuntosVidaMax();

	List<Item> getArmas();

	List<Item> getEscudos();

	List<Item> getPociones();

	List<Item> getInventarioPasivoArmas();

	List<Item> getInventarioPasivoEscudos();

	List<Item> getInventarioPasivoPociones();
}
