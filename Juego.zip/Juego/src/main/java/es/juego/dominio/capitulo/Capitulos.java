package es.juego.dominio.capitulo;

import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Fachada pública del módulo de capítulos.
 *
 * Permite crear o reconstruir capítulos a partir de:
 *  - una temática
 *  - una lista de eventos (1..n)
 *  - un villano final
 */
public final class Capitulos {

    private Capitulos() {
        // no instanciable
    }

    /**
     * Crea o reconstruye un capítulo completo.
     *
     * @param tematica temática del capítulo
     * @param eventos lista de eventos (no vacía)
     * @param villanoFinal criatura que actúa como villano final
     */
    public static Capitulo crearOReconstruir(
            TematicaEventos tematica,
            List<Evento> eventos,
            Criatura villanoFinal
    ) {
        return CapituloAssembler.desdeDatos(tematica, eventos, villanoFinal);
    }
}
