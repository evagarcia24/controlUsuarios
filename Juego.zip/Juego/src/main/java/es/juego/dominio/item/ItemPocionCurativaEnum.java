package es.juego.dominio.item;

import lombok.Getter;

@Getter
enum ItemPocionCurativaEnum implements Item {

	// ============================================================
	// NIVEL 1 — Trámites menores, papeles simples (1–9)
	// ============================================================
	POC_LV1_01("Infusión de trámite básico", 1), POC_LV1_02("Tisana de sello húmedo", 2),
	POC_LV1_03("Gota de justificante extraviado", 3), POC_LV1_04("Jarabe de ventanilla fría", 4),
	POC_LV1_05("Pócima de espera silenciosa", 5), POC_LV1_06("Esencia de turno inicial", 6),
	POC_LV1_07("Mejunje de formulario incompleto", 7), POC_LV1_08("Extracto de oficina apagada", 8),
	POC_LV1_09("Brebaje de sello borroso", 9),

	// ============================================================
	// NIVEL 2 — Registros, firmas, incidencias (10–19)
	// ============================================================
	POC_LV2_10("Infusión de registro oxidado", 10), POC_LV2_11("Tónico de justificante arrugado", 11),
	POC_LV2_12("Jarabe de comité lento", 12), POC_LV2_13("Emulsión de ventanilla cerrada", 13),
	POC_LV2_14("Pócima de firma movida", 14), POC_LV2_15("Esencia de expediente básico", 15),
	POC_LV2_16("Concentrado de proceso duplicado", 16), POC_LV2_17("Extracto de reunión sin inicio", 17),
	POC_LV2_18("Brebaje de incidencia menor", 18), POC_LV2_19("Sirope de papeleo templado", 19),

	// ============================================================
	// NIVEL 3 — Formularios fallidos, solicitudes ambiguas (20–29)
	// ============================================================
	POC_LV3_20("Gota de formulario fallido", 20), POC_LV3_21("Pócima de listado ambiguo", 21),
	POC_LV3_22("Tisana de sellado impreciso", 22), POC_LV3_23("Extracto de informe disperso", 23),
	POC_LV3_24("Bálsamo de cronograma dudoso", 24), POC_LV3_25("Elixir de comité revisado", 25),
	POC_LV3_26("Mejunje de solicitud lenta", 26), POC_LV3_27("Infusión de norma borrosa", 27),
	POC_LV3_28("Cordial de inscripción pálida", 28), POC_LV3_29("Decocción de sesión aplazada", 29),

	// ============================================================
	// NIVEL 4 — Comités, calendario obstruido, mesas saturadas (30–39)
	// ============================================================
	POC_LV4_30("Extracto de trámite insistente", 30), POC_LV4_31("Infusión de registro torcido", 31),
	POC_LV4_32("Jarabe de comité circular", 32), POC_LV4_33("Pócima de calendario obstruido", 33),
	POC_LV4_34("Mejunje de solicitud variable", 34), POC_LV4_35("Ungüento de protocolo repetido", 35),
	POC_LV4_36("Esencia de documento vibrante", 36), POC_LV4_37("Tónico de acta incompleta", 37),
	POC_LV4_38("Brebaje de mesa saturada", 38), POC_LV4_39("Gota de expediente profundo", 39),

	// ============================================================
	// NIVEL 5 — Debates, permisos ambiguos, revisiones eternas (40–49)
	// ============================================================
	POC_LV5_40("Infusión de debate cansino", 40), POC_LV5_41("Jarabe de horario imposible", 41),
	POC_LV5_42("Pócima de ventanilla dual", 42), POC_LV5_43("Extracto de permiso ambiguo", 43),
	POC_LV5_44("Cordial de firma revocada", 44), POC_LV5_45("Esencia de informe persistente", 45),
	POC_LV5_46("Tónica de solicitud circular", 46), POC_LV5_47("Mejunje de turno distante", 47),
	POC_LV5_48("Bálsamo de registro desplazado", 48), POC_LV5_49("Elixir de revisión interminable", 49),

	// ============================================================
	// NIVEL 6 — Auditorías fantasma, procesos mutantes, autorizaciones volátiles
	// (50–59)
	// ============================================================
	POC_LV6_50("Extracto de auditoría fantasma", 50), POC_LV6_51("Pócima de turno recursivo", 51),
	POC_LV6_52("Tisana de expediente mutante", 52), POC_LV6_53("Gota de solicitud paralela", 53),
	POC_LV6_54("Brebaje de evaluación ambigua", 54), POC_LV6_55("Jarabe de autorización volátil", 55),
	POC_LV6_56("Elixir de acta itinerante", 56), POC_LV6_57("Concentrado de firma migratoria", 57),
	POC_LV6_58("Cordial de reglamento elástico", 58), POC_LV6_59("Esencia de trámite revivido", 59),

	// ============================================================
	// NIVEL 7 — Comisiones perpetuas, normas delirantes, turnos ilusorios (60–69)
	// ============================================================
	POC_LV7_60("Infusión de comisión perpetua", 60), POC_LV7_61("Jarabe de acta mutable", 61),
	POC_LV7_62("Tónico de expediente abisal", 62), POC_LV7_63("Bálsamo de revisión espectral", 63),
	POC_LV7_64("Extracto de norma delirante", 64), POC_LV7_65("Pócima de gestión duplicada", 65),
	POC_LV7_66("Mejunje de turno ilusorio", 66), POC_LV7_67("Ungüento de recurso agotado", 67),
	POC_LV7_68("Tisana de comisión paralela", 68), POC_LV7_69("Decocción de trámite colapsado", 69),

	// ============================================================
	// NIVEL 8 — Reglamentos supremos, actas impenetrables, procesos absolutos
	// (70–79)
	// ============================================================
	POC_LV8_70("Elixir de firma trascendental", 70), POC_LV8_71("Jarabe de reglamento supremo", 71),
	POC_LV8_72("Extracto de acta impenetrable", 72), POC_LV8_73("Pócima de registro absoluto", 73),
	POC_LV8_74("Tisana de comité insondable", 74), POC_LV8_75("Mejunje de protocolo primordial", 75),
	POC_LV8_76("Esencia de trámite arcano", 76), POC_LV8_77("Cordial de autorización férrea", 77),
	POC_LV8_78("Brebaje de firma eterna", 78), POC_LV8_79("Gota de acta soberana", 79),

	// ============================================================
	// NIVEL 9 — Supertrámites, decretos pétreos, expedientes definitivos (80–89)
	// ============================================================
	POC_LV9_80("Infusión de supertrámite", 80), POC_LV9_81("Concentrado de reglamento pétreo", 81),
	POC_LV9_82("Jarabe de comisión titánica", 82), POC_LV9_83("Extracto de expediente definitivo", 83),
	POC_LV9_84("Pócima de firma colosal", 84), POC_LV9_85("Esencia de turno supremo", 85),
	POC_LV9_86("Bálsamo de registro inamovible", 86), POC_LV9_87("Elixir de aprobación total", 87),
	POC_LV9_88("Gota de certificado inmortal", 88), POC_LV9_89("Decocción de trámite final", 89),

	// ============================================================
	// NIVEL 10 — Trámites primordiales, decretos finales, firmas divinas (90–99)
	// ============================================================
	POC_LV10_90("Pócima de acta primordial", 90), POC_LV10_91("Jarabe de autorización absoluta", 91),
	POC_LV10_92("Extracto de trámite eterno", 92), POC_LV10_93("Elixir de reglamento legendario", 93),
	POC_LV10_94("Brebaje de comisión infinita", 94), POC_LV10_95("Esencia de firma divina", 95),
	POC_LV10_96("Tónico de turno ancestral", 96), POC_LV10_97("Cordial de registro inquebrantable", 97),
	POC_LV10_98("Infusión de acta suprema", 98), POC_LV10_99("Pócima del decreto final", 99),

	// ============================================================
	// NIVEL 11 — Temática: transformación interior, limitaciones metafísicas,
	// aprendizaje humano (100–109)
	// ============================================================
	POC_LV11_100("Elixir de introspección radical", 100), POC_LV11_101("Tónico de comprensión incompleta", 101),
	POC_LV11_102("Gota de autoconciencia vulnerable", 102), POC_LV11_103("Infusión de percepción emergente", 103),
	POC_LV11_104("Brebaje de verdad incómoda", 104), POC_LV11_105("Esencia de cambio inevitable", 105),
	POC_LV11_106("Decocción de sombra interior", 106), POC_LV11_107("Pócima de duda trascendental", 107),
	POC_LV11_108("Extracto de límite ontológico", 108), POC_LV11_109("Concentrado de potencial humano latente", 109);

	private final String nombre;
	private final int puntos;

	ItemPocionCurativaEnum(String nombre, int puntos) {
		this.nombre = nombre;
		this.puntos = puntos;
	}

	@Override
	public int getNivel() {
		return getPuntos() / 10 + 1;
	}

}
