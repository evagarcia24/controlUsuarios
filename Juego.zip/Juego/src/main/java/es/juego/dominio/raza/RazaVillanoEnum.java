package es.juego.dominio.raza;

import lombok.Getter;

@Getter
enum RazaVillanoEnum implements Raza {

    // ============================
    // 1 — Burocracia Disfuncional
    // ============================
    VIL_BURO_01("Administración Inoperante", 6, 10, 2, 3),
    VIL_BURO_02("Tramitación Caótica", 5, 7, 5, 8),
    VIL_BURO_03("Máquina Administrativa Estancada", 7, 9, 4, 6),
    VIL_BURO_04("Aparato Burocrático Ineficaz", 5, 8, 5, 7),
    VIL_BURO_05("Gestión Pública Entorpecida", 4, 6, 8, 10),
    VIL_BURO_06("Engranaje Administrativo Roto", 3, 7, 6, 9),
    VIL_BURO_07("Sistema de Trámites Fallido", 9, 10, 3, 5),
    VIL_BURO_08("Estructura Institucional Disfuncional", 7, 9, 4, 8),
    VIL_BURO_09("Organigrama Estatal Paralizado", 8, 7, 6, 6),
    VIL_BURO_10("Marco Institucional Torcido", 4, 6, 7, 9),

    // ============================
    // 2 — Corrupción y Escándalos
    // ============================
    VIL_CORR_01("Trama de Corrupción y Desprestigio", 6, 7, 5, 8),
    VIL_CORR_02("Red de Sobornos y Escándalos", 7, 8, 4, 7),
    VIL_CORR_03("Escándalos Institucionales y Cohechos", 6, 6, 6, 7),
    VIL_CORR_04("Manejos Corruptos y Revelaciones", 7, 7, 5, 8),
    VIL_CORR_05("Conspiración de Fraude y Vergüenzas Públicas", 5, 7, 6, 9),
    VIL_CORR_06("Caso de Coimas y Turbulencias Políticas", 6, 5, 6, 10),
    VIL_CORR_07("Operación de Enriquecimiento Ilícito y Polémicas", 5, 8, 5, 8),
    VIL_CORR_08("Red de Malversación y Bochorno Público", 6, 6, 7, 8),
    VIL_CORR_09("Intrigas Corruptas y Crisis Mediáticas", 5, 5, 8, 9),
    VIL_CORR_10("Escándalos Mediáticos del Poder", 4, 7, 5, 10),

    // ============================
    // 3 — Instituciones Deformadas
    // ============================
    VIL_INST_01("Organismos Desfigurados", 3, 10, 2, 5),
    VIL_INST_02("Entidades Públicas Distorsionadas", 6, 9, 4, 7),
    VIL_INST_03("Estructuras Institucionales Corrompidas", 7, 8, 4, 8),
    VIL_INST_04("Aparato Estatal Deformado", 6, 9, 3, 9),
    VIL_INST_05("Instituciones Alteradas y Desviadas", 4, 8, 5, 9),
    VIL_INST_06("Administración Desnaturalizada", 3, 10, 2, 8),
    VIL_INST_07("Arquitectura Institucional Deteriorada", 5, 10, 2, 6),
    VIL_INST_08("Sistema Público Desfigurado", 6, 7, 6, 7),
    VIL_INST_09("Marco Institucional Torcido", 4, 10, 2, 6),
    VIL_INST_10("Estructura Institucional Quebrada", 6, 8, 3, 7),

    // ======================================
    // 4 — Economía, Crisis y Mercado Laboral
    // ======================================
    VIL_ECON_01("Economía en Declive, Crisis y Desempleo", 7, 5, 6, 9),
    VIL_ECON_02("Turbulencias Económicas y Tensión Laboral", 6, 7, 5, 8),
    VIL_ECON_03("Mercado Laboral Precario y Desajustes Económicos", 5, 6, 8, 9),
    VIL_ECON_04("Crisis Financiera y Desorden en el Empleo", 8, 9, 3, 6),
    VIL_ECON_05("Inestabilidad Económica y Colapso del Trabajo", 8, 10, 2, 5),
    VIL_ECON_06("Desaceleración Económica y Estrés Laboral", 4, 7, 7, 8),
    VIL_ECON_07("Problemas Macroeconómicos y Deterioro Laboral", 5, 6, 8, 7),
    VIL_ECON_08("Recesión y Fragilidad del Empleo", 6, 7, 6, 8),
    VIL_ECON_09("Desorden Económico y Vulnerabilidad Laboral", 8, 8, 4, 7),
    VIL_ECON_10("Colapso Laboral Sistémico", 6, 8, 5, 7),

    // ============================
    // 5 — Medios y Comunicación
    // ============================
    VIL_MEDI_01("Máquina Mediática Manipuladora", 4, 5, 9, 10),
    VIL_MEDI_02("Altavoz de la Desinformación", 3, 5, 10, 10),
    VIL_MEDI_03("Prensa del Caos Narrativo", 5, 6, 7, 9),
    VIL_MEDI_04("Canal de Ruido y Opiniones Infladas", 4, 6, 8, 9),
    VIL_MEDI_05("Agencia de Tendenciosidad Permanente", 4, 7, 6, 10),
    VIL_MEDI_06("Red de Manipulación Informativa", 5, 7, 6, 9),
    VIL_MEDI_07("Plataforma de Espectáculo y Exageración", 5, 6, 7, 10),
    VIL_MEDI_08("Corporación del Bulo Sofisticado", 3, 8, 6, 10),
    VIL_MEDI_09("Sindicato del Sensacionalismo Permanente", 4, 6, 9, 8),
    VIL_MEDI_10("Fábrica de Narrativas Distorsionadas", 5, 7, 6, 10),

    // ============================================
    // 6 — Infraestructuras Deficientes
    // ============================================
    VIL_INFR_01("Obras Eternas y Resultados Mediocres", 7, 10, 1, 4),
    VIL_INFR_02("Red de Servicios Medio Rotos", 5, 7, 4, 9),
    VIL_INFR_03("Ingeniería del Parcheo Permanente", 7, 9, 2, 7),
    VIL_INFR_04("Infraestructura del Aplazamiento Infinito", 6, 9, 4, 7),
    VIL_INFR_05("Sistema Público de Averías Programadas", 8, 8, 3, 6),
    VIL_INFR_06("Autovías del Desgaste y la Chapuza", 5, 10, 3, 6),
    VIL_INFR_07("Red Estatal de Colapsos Recurrentes", 6, 7, 7, 6),
    VIL_INFR_08("Arquitectura del Mantenimiento Imaginario", 6, 8, 5, 6),
    VIL_INFR_09("Plataforma Nacional de Fallos Estructurales", 4, 8, 4, 9),
    VIL_INFR_10("Infraestructura de Tercera Mano", 7, 7, 4, 8),

    // ============================================
    // 7 — Ideología y Tensiones Territoriales
    // ============================================
    VIL_IDEO_01("Choque de Dogmas y Fronteras Internas", 5, 7, 7, 9),
    VIL_IDEO_02("Bloc de Tensiones Identitarias", 5, 6, 9, 8),
    VIL_IDEO_03("Facción de Ideologías en Guerra Fría", 7, 5, 8, 7),
    VIL_IDEO_04("Liga de Reinos Cabreados", 5, 6, 7, 10),
    VIL_IDEO_05("Alianza de Patrias en Competencia", 7, 8, 5, 6),
    VIL_IDEO_06("Cofradía de Símbolos Enfrentados", 6, 8, 5, 7),
    VIL_IDEO_07("Tribunal de Ideas Incompatibles", 5, 7, 6, 9),
    VIL_IDEO_08("Federación de Agravios Históricos", 4, 7, 6, 10),
    VIL_IDEO_09("Hermandad de Territorios Susceptibles", 4, 6, 8, 9),
    VIL_IDEO_10("Presión Ideológica Callejera", 7, 6, 7, 5),

    // ============================================
    // 8 — Servicios Públicos Colapsados
    // ============================================
    VIL_SERV_01("Administración de Turnos Interminables", 4, 10, 2, 6),
    VIL_SERV_02("Oficina del Colapso Eterno", 5, 8, 3, 8),
    VIL_SERV_03("Agencia del Sobresaturamiento Público", 6, 7, 5, 7),
    VIL_SERV_04("Red de Servicios en Estado Agónico", 8, 9, 3, 5),
    VIL_SERV_05("Instituto del Desborde Administrativo", 6, 6, 7, 7),
    VIL_SERV_06("Plataforma de Atención Imposible", 5, 9, 3, 6),
    VIL_SERV_07("Centro de Gestión Saturada", 4, 6, 7, 9),
    VIL_SERV_08("Consejería del Caos Operativo", 5, 7, 6, 7),
    VIL_SERV_09("Autoridad del Servicio Inaccesible", 4, 6, 8, 8),
    VIL_SERV_10("Agencia del Servicio Imposible", 3, 9, 4, 8),

	// ============================================================
	// 9 — Metafísica Sarcástica y Limitaciones Humanas
	// ============================================================
	VIL_META_01("Paradoja Andante de Autoengaño Premeditado", 6, 7, 5, 9),
	VIL_META_02("Somatización Viviente del Agobio Diario", 5, 9, 4, 8),
	VIL_META_03("Avatar de la Procrastinación Filosófica", 4, 6, 7, 10),
	VIL_META_04("Reflejo Distorsionado de Expectativas Realistas", 6, 8, 5, 7),
	VIL_META_05("Encarnación del Pensamiento Repetitivo Inútil", 7, 7, 4, 9),
	VIL_META_06("Manifestación Ambigua de la Identidad Mutable", 5, 8, 6, 8),
	VIL_META_07("Espectro de la Opinión Contradictoria Permanente", 4, 6, 9, 7),
	VIL_META_08("Eco Inestable de Decisiones Mal Tomadas", 6, 7, 5, 10),
	VIL_META_09("Cúmulo de Sesgos Cognitivos Errantes", 5, 8, 6, 9),
	VIL_META_10("Entropía Social con Carga Existencial Acumulada", 7, 7, 4, 8);

    private final String tipo;
    private final int fuerza;
    private final int resistencia;
    private final int velocidad;
    private final int magia;

    RazaVillanoEnum(String tipo, int fuerza, int resistencia, int velocidad, int magia) {
        this.tipo = tipo;
        this.fuerza = fuerza;
        this.resistencia = resistencia;
        this.velocidad = velocidad;
        this.magia = magia;
    }
}
