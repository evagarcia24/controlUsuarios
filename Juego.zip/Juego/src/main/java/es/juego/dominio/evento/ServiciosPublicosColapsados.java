package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum ServiciosPublicosColapsados implements EnumEventoNarrativo  {

    HOSPITAL_SATURADO(
        "Hospital Saturado",
        "El hospital está abarrotado y los pasillos están llenos de pacientes, camillas y papeles desordenados.",

        "Intentar ayudar a organizar la sala",
        "Buscar un desvío para evitar el caos",

        "Una camilla fuera de control te golpea en la pierna.",
        "Tu presencia pasa desapercibida entre el desorden.",
        "Un sanitario agradece tu ayuda con un pequeño recurso.",
        "La sala se aclara brevemente y recibes una oleada de vitalidad."
    ),

    COLA_ADMINISTRATIVA_ETERNIZADA(
        "Cola Administrativa Eternizada",
        "Una interminable cola para un trámite público se extiende durante metros, sin avanzar ni un centímetro.",

        "Intentar mejorar el flujo de la cola",
        "Salir discretamente antes de quedar atrapado",

        "Sufres un empujón accidental de un ciudadano frustrado.",
        "La cola sigue estancada sin afectarte.",
        "Consigues optimizar un tramo y hallas un pequeño obsequio.",
        "La cola se mueve milagrosamente y te infunde energía renovadora."
    ),

    TRANSPORTE_COLAPSADO(
        "Transporte Colapsado",
        "Los autobuses y trenes están tan llenos que parecen fusionados en una masa vibrante de pasajeros.",

        "Intentar ordenar la entrada y salida de pasajeros",
        "Evitar el transporte por completo",

        "Un pasajero tropieza contigo y te golpea.",
        "El transporte ni mejora ni empeora para ti.",
        "Organizas un acceso temporal y encuentras un objeto útil.",
        "Una ola de cooperación espontánea te revitaliza."
    ),

    ESCUELA_DESBORDADA(
        "Escuela Desbordada",
        "Una escuela pública ha duplicado misteriosamente su alumnado y nadie sabe dónde ubicar a tantos estudiantes.",

        "Ayudar a reorganizar las aulas",
        "Evitar el edificio antes de quedar atrapado",

        "Una pila de libros desbordada cae sobre tu pie.",
        "Los profesores no te notan en medio del caos.",
        "Encuentras un material útil entre los pupitres.",
        "Una clase improvisada te inspira y llena de vitalidad."
    ),

    URGENCIAS_QUEMADAS(
        "Urgencias Quemadas",
        "El servicio de urgencias arde metafóricamente mientras el personal intenta apagar cientos de problemas a la vez.",

        "Intentar apagar algún fuego administrativo",
        "Rodear la zona crítica",

        "Un fichero incandescente te quema ligeramente.",
        "Los 'incendios' siguen sin tocarte.",
        "Ayudas a resolver un caso y recibes un pequeño recurso.",
        "Uno de los médicos te agradece profundamente y tu energía aumenta."
    ),

    INFOPUNTO_CAIDO(
        "Infopunto Caído",
        "Una máquina de información pública parpadea mientras una voz robótica repite mensajes sin sentido.",

        "Intentar reparar el infopunto",
        "Alejarte antes de que vuelva a fallar",

        "Un chispazo de la pantalla te impacta.",
        "La máquina crashea sin consecuencias para ti.",
        "Restauras una función y recuperas un objeto útil.",
        "La máquina reinicia un modo avanzado que te revitaliza."
    ),

    PARQUE_COLAPSADO(
        "Parque Colapsado",
        "Un parque público tiene columpios rotos, fuentes desbordadas y bancos que se mueven solos por el desgaste extremo.",

        "Intentar reparar algún elemento",
        "Evitar el parque y continuar",

        "Un columpio roto golpea tu brazo.",
        "El parque sigue caótico sin afectarte.",
        "Encuentras un pequeño objeto en una fuente vacía.",
        "Una corriente fresca de la fuente renovada te llena de vitalidad."
    ),

    BOMBEROS_DESBORDADOS(
        "Bomberos Desbordados",
        "El cuartel de bomberos se encuentra respondiendo a tantas emergencias que sus sirenas se solapan en un coro caótico.",

        "Ayudar a despejar el área",
        "Apartarte de la confusión",

        "Uno de los camiones casi te roza al maniobrar.",
        "La actividad frenética no te afecta.",
        "Ayudas a recolocar una manguera y recibes un pequeño obsequio.",
        "Un bombero agradecido te transmite una fuerte energía vital."
    ),

    BIBLIOTECA_REPLETA(
        "Biblioteca Repleta",
        "La biblioteca está tan llena que los libros parecen multiplicarse espontáneamente mientras las mesas desaparecen.",

        "Ordenar una sección",
        "Rodear la biblioteca sin entrar",

        "Un libro cae desde una estantería alta y te golpea.",
        "Los libros se mueven sin tocarte.",
        "Encuentras un volumen valioso abandonado.",
        "Una estantería se abre revelando un brillo que te revitaliza."
    ),

    PAPELEO_ATASCADO(
        "Papeleo Atascado",
        "Una oficina pública está completamente colapsada con trámites que se acumulan hasta el techo.",

        "Intentar tramitar una parte del papeleo",
        "Retirarte antes de que te asignen una cola",

        "Un archivador cae y te golpea la mano.",
        "El papeleo sigue atascado sin consecuencias.",
        "Resuelves un trámite menor y obtienes un pequeño recurso.",
        "El papeleo cede de forma milagrosa y recibes una fuerte oleada de vitalidad."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    ServiciosPublicosColapsados(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
