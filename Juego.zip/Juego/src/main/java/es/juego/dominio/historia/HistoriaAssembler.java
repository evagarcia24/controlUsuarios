package es.juego.dominio.historia;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;

/**
 * Ensamblador interno encargado de reconstruir una historia desde
 * datos proporcionados por la capa de aplicación o por una capa de
 * persistencia.
 *
 * No se encarga de generar contenido ni reglas narrativas; su labor
 * consiste únicamente en ensamblar el agregado respetando sus
 * invariantes internas.
 */
final class HistoriaAssembler {

    private HistoriaAssembler() {}

    static Historia desdeDatos(
            List<Capitulo> capitulos,
            int numeroCapitulos,
            Criatura villanoFinalDeHistoria
    ) {
        return new HistoriaBase(capitulos, numeroCapitulos, villanoFinalDeHistoria);
    }
}
