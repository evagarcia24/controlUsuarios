package es.juego.dominio.dado;

/**
 * Define quién ejecuta la tirada del dado:
 * automático, interactivo, fijo...
 */
public interface Lanzador {
    int lanzar(Caras caras);
}
