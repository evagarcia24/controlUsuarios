package es.juego.dominio.raza;

import lombok.Getter;
import lombok.AllArgsConstructor;
import lombok.AccessLevel;

@Getter
@AllArgsConstructor(access = AccessLevel.PACKAGE)
class RazaBase implements Raza {

    private final String tipo;
    private final int fuerza;
    private final int resistencia;
    private final int velocidad;
    private final int magia;
}
