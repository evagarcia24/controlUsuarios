package es.juego.dominio.raza;

import lombok.Getter;

@Getter
enum RazaHeroeEnum implements Raza {

    HER_01("Tramitón de Ventanilla Única", 6, 7, 5, 6),
    HER_02("Archivista del Olvido Eterno", 4, 9, 4, 7),
    HER_03("Espectro de Cita Previa", 5, 6, 8, 5),
    HER_04("Goblin de la Subcomisión", 6, 6, 6, 6),
    HER_05("Duende del Sello Triple", 4, 7, 7, 6),
    HER_06("Invocador de Informes Extraviados", 5, 6, 6, 7),
    HER_07("Hidra de Reunión Interminable", 7, 8, 4, 5),
    HER_08("Sombra del Turno Perdido", 6, 6, 7, 5),
    HER_09("Cronista del Acta Eterna", 4, 8, 5, 7),
    HER_10("Burócrata Arcádico", 5, 7, 5, 7),

    HER_11("Fantasma del Certificado Volátil", 4, 5, 9, 5),
    HER_12("Ser del Recurso Infinito", 5, 7, 5, 7),
    HER_13("Espíritu de la Mesa Redonda Redonda", 5, 6, 6, 7),
    HER_14("Nimbo del Expediente Sombrío", 6, 7, 4, 7),
    HER_15("Tecnicolor de la Comisión Borrosa", 4, 6, 8, 6),
    HER_16("Druida del Acuerdo Tentativo", 5, 7, 4, 8),
    HER_17("Mago del Trámite Circular", 6, 6, 5, 7),
    HER_18("Ninfador del Registro Saturado", 6, 7, 6, 5),
    HER_19("Oráculo de la Fe de Erratas", 4, 8, 5, 7),
    HER_20("Guardián de la Urna Caprichosa", 7, 7, 5, 5),

    HER_21("Sirviente del Tablón de Anuncios", 6, 8, 4, 6),
    HER_22("Calígrafo de la Firma Borrosa", 4, 6, 8, 6),
    HER_23("Centinela de la Lista Provisional", 7, 7, 5, 5),
    HER_24("Hombre del Papeleo Perpetuo", 5, 7, 5, 7),
    HER_25("Mujer de la Resolución Helada", 4, 9, 4, 7),
    HER_26("Vigía del Censo Movedizo", 5, 6, 8, 5),
    HER_27("Siervo de la Copia Certificada", 6, 8, 4, 6),
    HER_28("Órgano de la Consulta Aplazada", 4, 8, 5, 7),
    HER_29("Avatar del Procedimiento Arcaico", 7, 6, 4, 7),
    HER_30("Heraut del Comunicado Oficial", 5, 6, 7, 6),

    HER_31("Mensajero del Sobre Abollado", 6, 6, 7, 5),
    HER_32("Guardián de la Bandeja de Entrada", 7, 7, 4, 6),
    HER_33("Custodio del Archivo Muerto", 5, 9, 4, 6),
    HER_34("Sombra del Permiso Pendiente", 5, 7, 6, 6),
    HER_35("Esfinge de la Urgencia Relativa", 4, 8, 6, 6),
    HER_36("Vigilante del Plazo Agotado", 7, 7, 4, 6),
    HER_37("Eco de la Orden Reiterada", 5, 6, 7, 6),
    HER_38("Adepta de la Junta Permanente", 4, 7, 6, 7),
    HER_39("Aparato del Turno Migratorio", 6, 6, 6, 6),
    HER_40("Clérigo de la Compulsa Triple", 6, 8, 4, 6),

    HER_41("Gigante de la Comisión Dormida", 7, 8, 3, 6),
    HER_42("Mendigo de la Papeleta Rota", 5, 5, 8, 6),
    HER_43("Profeta del Reglamento Mutante", 4, 7, 6, 7),
    HER_44("Censador de Largo Aliento", 6, 8, 5, 5),
    HER_45("Espiritual Acta-Walker", 5, 7, 6, 6),
    HER_46("Patriarca de la Notificación Tardía", 5, 8, 5, 6),
    HER_47("Matriarca de la Cola Triple", 6, 7, 6, 5),
    HER_48("Moderador de la Asamblea Eternizada", 5, 7, 5, 7),
    HER_49("Entidad de la Declaración Ambigua", 5, 6, 6, 7),
    HER_50("Veedor del Certificado Suspendido", 6, 8, 4, 6),

    HER_51("Sombra del Carnet Extraviado", 5, 6, 7, 6),
    HER_52("Heredero del Trámite Espejismo", 5, 7, 6, 6),
    HER_53("Coleccionista de Fotocopia Mala", 7, 6, 7, 4),
    HER_54("Eterno del Pase Circular", 5, 7, 5, 7),
    HER_55("Supervisor de la Cita Oscilante", 4, 7, 7, 6),
    HER_56("Inspector del Papeleo Crónico", 6, 8, 4, 6),
    HER_57("Caballero de la Urna Dormida", 7, 7, 5, 5),
    HER_58("Monje del Recurso Eternal", 5, 7, 5, 7),
    HER_59("Nómada de la Ventanilla Opaca", 6, 6, 7, 5),
    HER_60("Somnia del Acta Suspendida", 4, 8, 5, 7),

    HER_61("Maestre de la Resolución Doble", 6, 7, 5, 6),
    HER_62("Examinador del Documento Infinito", 5, 7, 5, 7),
    HER_63("Portador de la Clave Perdida", 4, 6, 7, 7),
    HER_64("Guerrero del Turno Quebrado", 7, 6, 7, 4),
    HER_65("Acólito del Expediente Mudo", 5, 8, 5, 6),
    HER_66("Criatura del Boletín Desesperado", 6, 7, 5, 6),
    HER_67("Dama de la Cita Saltarina", 5, 6, 8, 5),
    HER_68("Doncel del Permiso Volátil", 6, 6, 6, 6),
    HER_69("Adepta del Cuño Orbital", 4, 8, 6, 6),
    HER_70("Custodio del Telegrama Tardío", 6, 7, 4, 7),

    HER_71("Infante de la Firma Errante", 5, 6, 7, 6),
    HER_72("Testigo de la Papeleta Humeante", 6, 7, 7, 4),
    HER_73("Calculista del Censo Perezoso", 4, 8, 5, 7),
    HER_74("Ponente del Acta Inclinada", 5, 7, 6, 6),
    HER_75("Duende del Documento Obstinado", 6, 6, 6, 6),
    HER_76("Cronista del Trámite Interrumpido", 5, 7, 6, 6),
    HER_77("Orador de la Reunión Expandida", 4, 7, 7, 7),
    HER_78("Narrador del Certificado Doble", 6, 7, 4, 7),
    HER_79("Mediador de la Mesa Vacilante", 6, 8, 5, 5),
    HER_80("Veedor de la Orden Pendular", 5, 6, 7, 6);

    private final String tipo;
    private final int fuerza;
    private final int resistencia;
    private final int velocidad;
    private final int magia;

    RazaHeroeEnum(String tipo, int fuerza, int resistencia, int velocidad, int magia) {
        this.tipo = tipo;
        this.fuerza = fuerza;
        this.resistencia = resistencia;
        this.velocidad = velocidad;
        this.magia = magia;
    }
}
