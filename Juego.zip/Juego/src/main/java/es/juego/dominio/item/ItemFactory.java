/**
 * Factoría interna para trabajar con catálogos de ítems modelados como enums.
 *
 * <p>La jerarquía de ítems del dominio está definida como un conjunto cerrado
 * ({@code sealed}) de enumeraciones que implementan {@link Item}. Cada catálogo
 * (armas, escudos, pociones) es un enum independiente y no existen clases
 * adicionales que representen ítems. El propósito de esta factoría es ofrecer
 * operaciones genéricas, seguras y unificadas sobre todos ellos.
 *
 * <h2>Genéricos y obtención dinámica de valores</h2>
 * <p>El parámetro de tipo {@code <T extends Enum<T> & Item>} garantiza que:
 * <ul>
 *   <li>{@code T} es un enum concreto del catálogo correspondiente,</li>
 *   <li>{@code T} implementa la interfaz de dominio {@code Item}.</li>
 * </ul>
 *
 * <p>Dado que Java no permite invocar {@code values()} sobre un tipo genérico,
 * se requiere proporcionar el {@code Class<T>} del enum concreto. A través de
 * {@code clazz.getEnumConstants()} se obtiene dinámicamente la lista completa
 * de ítems del catálogo.
 *
 * <h2>Operaciones proporcionadas</h2>
 *
 * <p>La factoría ofrece tres grupos de utilidades:
 *
 * <h3>1) Consulta por nivel</h3>
 * <ul>
 *   <li>Obtener todos los ítems de un nivel concreto.</li>
 *   <li>Excluir una colección dada de ítems del mismo nivel.</li>
 * </ul>
 *
 * <h3>2) Reconstrucción exhaustiva desde un nombre de constante enum</h3>
 * <p>Al cargar ítems desde almacenamiento (JSON, BD, serialización), únicamente
 * se conserva el nombre exacto de la constante enum (p. ej. {@code "ARM_LV4_01"}).
 *
 * <p>Este nombre permite:
 * <ul>
 *   <li>inferir el catálogo al que pertenece (armas, escudos, pociones) gracias
 *       al prefijo convencional del dominio ({@code ARM_}, {@code ESC_},
 *       {@code POC_}),</li>
 *   <li>obtener de forma determinista el ítem real del dominio mediante
 *       {@code fromNombre(...)}.</li>
 * </ul>
 *
 * <h3>3) Reconstrucción masiva</h3>
 * <p>A partir de una colección de cadenas con nombres de constantes enum,
 * {@code reconstruirListaSoloConNombres(...)} devuelve la lista real de ítems
 * de dominio.
 *
 * <h2>Resumen</h2>
 * <p>Esta clase elimina la necesidad de repetir código en cada catálogo,
 * centraliza la reconstrucción desde almacenamiento y garantiza que los
 * catálogos de ítems se manipulan de forma consistente con el modelo cerrado
 * del dominio.</p>
 */


package es.juego.dominio.item;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

final class ItemFactory {

	private ItemFactory() {
	}

	/**
	 * Devuelve todos los ítems del catálogo indicado cuyo nivel coincide con
	 * {@code nivel}.
	 *
	 * <p>El catálogo se determina a partir del enum concreto proporcionado en
	 * {@code clazz}. La obtención de los ítems se realiza mediante
	 * {@code clazz.getEnumConstants()}, ya que no es posible invocar
	 * {@code values()} desde un tipo genérico.
	 *
	 * @param clazz enum concreto que representa el catálogo (armas, escudos, pociones)
	 * @param nivel nivel por el cual se filtran los ítems
	 * @param <T>   tipo genérico que representa un catálogo que implementa {@link Item}
	 * @return lista de ítems cuyo {@code getNivel()} coincide con {@code nivel}
	 */
	static <T extends Enum<T> & Item> List<Item> listaPorNivel(Class<T> clazz, int nivel) {

		List<Item> lista = new ArrayList<>();
		for (T t : clazz.getEnumConstants()) {
			if (t.getNivel() == nivel) {
				lista.add(t); // T es Item: conversión segura
			}
		}
		return lista;
	}

	/**
	 * Devuelve todos los ítems del catálogo indicado para un nivel concreto,
	 * excluyendo aquellos que ya están presentes en la colección {@code excluir}.
	 *
	 * <p>Comportamiento:
	 * <ul>
	 *   <li>Si {@code excluir} es {@code null} o está vacía, se devuelven todos
	 *       los ítems del nivel.</li>
	 *   <li>En caso contrario, solo se devuelven aquellos ítems cuyo valor no
	 *       esté contenido en {@code excluir}.</li>
	 * </ul>
	 *
	 * @param clazz   enum concreto que representa el catálogo (armas, escudos, pociones)
	 * @param nivel   nivel por el cual se filtran los ítems
	 * @param excluir colección de ítems que deben excluirse del resultado
	 * @param <T>     tipo genérico que representa un catálogo que implementa {@link Item}
	 * @return lista de ítems disponibles sin los valores presentes en {@code excluir}
	 */
	static <T extends Enum<T> & Item> List<Item> disponiblesExcluyendo(Class<T> clazz, int nivel,
			Collection<? extends Item> excluir) {

		List<Item> todos = listaPorNivel(clazz, nivel);

		if (excluir == null || excluir.isEmpty()) {
			return todos; // no excluimos nada
		}

		List<Item> resultado = new ArrayList<>();
		for (Item item : todos) {
			if (!excluir.contains(item)) {
				resultado.add(item);
			}
		}
		return resultado;
	}

	/**
	 * Reconstruye un ítem concreto del dominio a partir del nombre exacto de
	 * su constante enum.
	 *
	 * <p>Este método infiere el catálogo al que pertenece el ítem examinando
	 * el prefijo del nombre:
	 * <ul>
	 *   <li>{@code ARM_} → armas</li>
	 *   <li>{@code ESC_} → escudos</li>
	 *   <li>{@code POC_} → pociones</li>
	 * </ul>
	 *
	 * <p>Es útil al cargar ítems desde almacenamiento (JSON, BD, serialización)
	 * donde únicamente se conserva el nombre de la constante enum.
	 *
	 * @param nombreEnum nombre exacto de la constante enum (por ejemplo: "ARM_LV4_01")
	 * @return ítem correspondiente del catálogo interno
	 * @throws IllegalArgumentException si el prefijo no corresponde a ningún catálogo válido
	 */

	static Item fromNombreSolo(String nombreEnum) {

		if (nombreEnum.startsWith("ARM_")) {
			return fromNombre(ItemArmaEnum.class, nombreEnum);
		}
		if (nombreEnum.startsWith("ESC_")) {
			return fromNombre(ItemEscudoEnum.class, nombreEnum);
		}
		if (nombreEnum.startsWith("POC_")) {
			return fromNombre(ItemPocionCurativaEnum.class, nombreEnum);
		}

		throw new IllegalArgumentException("No se puede inferir el tipo de ítem a partir del nombre: " + nombreEnum);
	}

	/**
	 * Devuelve la constante concreta del enum {@code clazz} cuyo nombre coincide
	 * exactamente con {@code nombreEnum}.
	 *
	 * <p>Este método es la operación fundamental para reconstruir un ítem del dominio
	 * cuando ya se conoce el catálogo concreto al que pertenece.
	 *
	 * @param clazz      enum concreto que implementa {@link Item}
	 * @param nombreEnum nombre exacto de la constante enum a localizar
	 * @param <T>        tipo genérico correspondiente al catálogo concreto
	 * @return la constante enum correspondiente
	 * @throws IllegalArgumentException si el catálogo no contiene una constante con ese nombre
	 */

	static <T extends Enum<T> & Item> Item fromNombre(Class<T> clazz, String nombreEnum) {

		for (T t : clazz.getEnumConstants()) {
			if (t.name().equals(nombreEnum)) {
				return t;
			}
		}

		throw new IllegalArgumentException("El catálogo " + clazz.getSimpleName() + " no contiene: " + nombreEnum);
	}

	/**
	 * Reconstruye una lista completa de ítems del dominio a partir de una colección
	 * de nombres exactos de constantes enum.
	 *
	 * <p>Cada entrada debe ser un nombre válido de un catálogo interno
	 * ({@code ARM_}, {@code ESC_}, {@code POC_}). La inferencia del tipo y la
	 * regeneración del ítem se realizan utilizando {@link #fromNombreSolo(String)}.
	 *
	 * <p>Si {@code ids} es {@code null}, se devuelve una lista vacía.
	 *
	 * @param ids colección de nombres de constantes enum
	 * @return lista de ítems reales del dominio reconstruidos a partir de sus nombres
	 */

	static List<Item> reconstruirListaSoloConNombres(Collection<String> ids) {

		List<Item> resultado = new ArrayList<>();
		if (ids == null) {
			return resultado;
		}

		for (String id : ids) {
			resultado.add(fromNombreSolo(id));
		}

		return resultado;
	}
}