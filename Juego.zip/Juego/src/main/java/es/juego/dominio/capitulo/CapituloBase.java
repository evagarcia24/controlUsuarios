package es.juego.dominio.capitulo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Implementación interna de Capitulo.
 * Solo mantiene estado inmutable.
 */
final class CapituloBase implements Capitulo {

    private final TematicaEventos tematica;
    private final List<Evento> eventos;
    private final Criatura villanoFinal;

    CapituloBase(TematicaEventos tematica,
                 List<Evento> eventos,
                 Criatura villanoFinal) {

        if (tematica == null) {
            throw new IllegalArgumentException("La temática del capítulo no puede ser null.");
        }
        if (eventos == null || eventos.isEmpty()) {
            throw new IllegalArgumentException("La lista de eventos del capítulo no puede ser null ni estar vacía.");
        }
        if (villanoFinal == null) {
            throw new IllegalArgumentException("El villano final del capítulo no puede ser null.");
        }

        this.tematica = tematica;
        this.eventos = new ArrayList<>(eventos);
        this.villanoFinal = villanoFinal;
    }

    @Override
    public TematicaEventos getTematica() {
        return tematica;
    }

    @Override
    public List<Evento> getEventos() {
        return Collections.unmodifiableList(eventos);
    }

    @Override
    public Criatura getVillano() {
        return villanoFinal;
    }
}
