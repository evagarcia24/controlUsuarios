package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum InfraestructurasDeficientes implements EnumEventoNarrativo  {

    ASCENSOR_QUE_CRUJE(
        "Ascensor que Cruje",
        "Un ascensor antiguo emite crujidos preocupantes cada vez que intentas abrir sus puertas oxidadas.",

        "Intentar usar el ascensor igualmente",
        "Tomar las escaleras de emergencia",

        "Un cable interior se tensa de golpe y la puerta te golpea la pierna.",
        "El ascensor simplemente no responde y sigues igual.",
        "El ascensor funciona durante unos segundos y encuentras un pequeño recurso dentro.",
        "El ascensor entra en un modo suave y te transmite una sensación revitalizadora."
    ),

    PUENTE_INESTABLE(
        "Puente Inestable",
        "Un pequeño puente dentro del recinto se balancea aunque no sopla viento alguno.",

        "Cruzarlo con cuidado",
        "Dar un rodeo para evitarlo",

        "Una tabla cede bajo tu pie y te provoca un mal aterrizaje.",
        "El puente se balancea, pero logras mantenerte sin cambios.",
        "Una tabla oculta revela un pequeño objeto útil.",
        "El puente permanece firme a tu paso como si te reconociera, llenándote de energía vital."
    ),

    ESCALERAS_RESBALADIZAS(
        "Escaleras Resbaladizas",
        "Las escaleras están cubiertas de un brillo extraño que hace imposible saber si es humedad o descuido extremo.",

        "Intentar subir con precisión",
        "Evitar la escalera y buscar otra ruta",

        "Resbalas y te golpeas ligeramente contra un peldaño.",
        "Subes con lentitud, pero sin consecuencias.",
        "Encuentras un pequeño objeto olvidado en un recoveco del pasamanos.",
        "Subes sin esfuerzo, sintiendo cómo la escalera refuerza tu vitalidad al final."
    ),

    TUBERIAS_GOTEANDO(
        "Tuberías Goteando",
        "Tuberías antiguas gotean sin cesar, creando charcos que parecen organizarse en pequeñas trampas naturales.",

        "Investigar la fuga",
        "Ignorar las tuberías y avanzar con cuidado",

        "Un chorro inesperado te golpea en la cara.",
        "El goteo continúa sin afectarte.",
        "Encuentras una llave inglesa olvidada con un pequeño beneficio.",
        "Descubres una válvula secreta que libera vapor revitalizante."
    ),

    PASILLO_INUNDADO(
        "Pasillo Inundado",
        "Un pasillo está cubierto por un agua turbia que no permite ver el suelo.",

        "Entrar con cuidado",
        "Rodear el pasillo",

        "Pisas algo cortante bajo el agua y te haces daño.",
        "El agua solo te moja los pies sin mayor problema.",
        "Encuentras un pequeño frasco flotando.",
        "Un remolino de agua pura se forma a tu lado y te transmite energía interior."
    ),

    ILUMINACION_DEFECTUOSA(
        "Iluminación Defectuosa",
        "Los fluorescentes parpadean creando sombras inquietantes que distorsionan el pasillo.",

        "Intentar ajustar la iluminación desde la caja eléctrica",
        "Seguir en penumbra sin intervenir en nada",

        "Una chispa salta de la caja y te causa una descarga leve.",
        "Las luces parpadean sin afectar tu recorrido.",
        "Consigues estabilizar un tramo y encuentras un objeto útil.",
        "La luz se vuelve clara y te envuelve en una calidez revitalizante."
    ),

    PUERTA_DEFORMADA(
        "Puerta Deformada",
        "Una puerta metálica se ha combado de forma antinatural, dificultando su apertura y emitiendo un chirrido inquietante.",

        "Intentar forzar la puerta",
        "Evitarla y buscar otra entrada",

        "La puerta se cierra de golpe y te roza el brazo.",
        "La puerta rechina, pero no ocurre nada más.",
        "Encuentras un pequeño objeto entre los marcos deformados.",
        "La puerta se acomoda a tu paso y te otorga un refuerzo vital inesperado."
    ),

    SUELO_VIBRANTE(
        "Suelo Vibrante",
        "El suelo vibra como si una maquinaria subterranea funcionara a medias, causando temblores irregulares.",

        "Averiguar el origen de la vibración",
        "Caminar rápidamente para evitar el temblor",

        "Un temblor repentino te hace tropezar.",
        "Las vibraciones continúan sin afectar tu estabilidad.",
        "Encuentras un pequeño objeto atrapado en una ranura.",
        "Un pulso de vibración armónica te llena de energía vital."
    ),

    CABLES_EXpuestos(
        "Cables Expuestos",
        "Varios cables eléctricos cuelgan del techo sin protección alguna, chisporroteando peligrosamente.",

        "Intentar recolocar los cables",
        "Pasar rápido esquivándolos",

        "Un chispazo te alcanza en el hombro.",
        "Los cables chisporrotean sin tocarte.",
        "Consigues apartar un cable que escondía un accesorio útil.",
        "Al recolocar un cable clave, una corriente cálida te fortalece."
    ),

    VENTANAS_ROTAS(
        "VentanAs Rotas",
        "Las ventanas del pasillo están agrietadas y dejan pasar ráfagas de aire frío que alteran la iluminación.",

        "Cerrar o asegurar las ventanas",
        "Acelerar el paso y evitar el frío",

        "Una astilla cae y te corta ligeramente.",
        "El aire frío solo te incomoda un poco.",
        "Encuentras un objeto útil en un alféizar suelto.",
        "Una corriente cálida inesperada te envuelve y te regenera."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    InfraestructurasDeficientes(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
