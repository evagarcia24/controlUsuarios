package es.juego.dominio.capitulo;

import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Representa un capítulo de la historia:
 *  - una temática narrativa
 *  - una secuencia de uno o más eventos
 *  - un villano final asociado.
 */
public interface Capitulo {

    /**
     * Temática principal del capítulo.
     */
    TematicaEventos getTematica();

    /**
     * Lista inmutable de eventos que componen el capítulo.
     * Debe contener al menos un evento.
     */
    List<Evento> getEventos();

    /**
     * Villano final del capítulo.
     */
    Criatura getVillano();
}
