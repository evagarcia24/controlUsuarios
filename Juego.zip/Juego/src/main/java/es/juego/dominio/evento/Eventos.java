package es.juego.dominio.evento;

import java.util.ArrayList;
import java.util.List;

/**
 * Fachada pública del módulo de eventos narrativos.
 *
 * Proporciona:
 *  - obtener dos eventos aleatorios distintos de una misma temática
 *
 * La aplicación nunca usa directamente los enums.
 * Siempre trabaja con la interfaz pública {@link Evento}.
 */
public final class Eventos {

    private Eventos() {
        // no instanciable
    }

    /**
     * Devuelve una lista con todos los eventos de una temática.
     */
    public static List<Evento> eventosTodos(TematicaEventos tematica) {

        EnumEventoNarrativo[] arr = valoresDeEnum(tematica);

        List<Evento> lista = new ArrayList<>(arr.length);

        for (EnumEventoNarrativo e : arr) {
            lista.add(EventoAssembler.desdeEnum(e));
        }

        return lista;
    }


    // =========================================================================
    // Helper interno: devuelve el array de enums para una temática
    // =========================================================================

    private static EnumEventoNarrativo[] valoresDeEnum(TematicaEventos t) {
        return switch (t) {
            case BUROCRACIA_DISFUNCIONAL      -> BurocraciaDisfuncional.values();
            case CORRUPCION_Y_ESCANDALOS      -> CorrupcionYEscandalos.values();
            case INSTITUCIONES_DEFORMADAS     -> InstitucionesDeformadas.values();
            case ECONOMIA_Y_CRISIS            -> EconomiaYCrisis.values();
            case MEDIOS_Y_COMUNICACION        -> MediosYComunicacion.values();
            case INFRAESTRUCTURAS_DEFICIENTES -> InfraestructurasDeficientes.values();
            case SERVICIOS_PUBLICOS_COLAPSADOS -> ServiciosPublicosColapsados.values();
            case IDEOLOGIA_Y_TENSIONES        -> IdeologiaYTensiones.values();
            default ->
                throw new IllegalArgumentException("Temática no soportada: " + t);
        };
    }
    
    /**
     * Reconstruye un evento narrativo desde datos persistidos.
     * Útil para cargar partidas guardadas.
     */
    public static Evento reconstruir(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus
    ) {
        return EventoAssembler.desdeDatos(
                titulo,
                descripcion,
                opcion1,
                opcion2,
                textoFracaso,
                textoNeutro,
                textoExito,
                textoVidaPlus
        );
    }

    /**
     * Devuelve las tematicas existentes.
     */
    public static List<TematicaEventos> tematicaTodas() {
        List<TematicaEventos> lista =
                new ArrayList<>(List.of(TematicaEventos.values()));

        return lista;
    }

}
