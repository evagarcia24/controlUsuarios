package es.juego.dominio.dado;

public final class Dado {

    private final Caras caras;
    private final Lanzador lanzador;

    public Dado(Caras caras, Lanzador lanzador) {
        this.caras = caras;
        this.lanzador = lanzador;
    }

    public int lanzar() {
        return lanzador.lanzar(caras);
    }
}
