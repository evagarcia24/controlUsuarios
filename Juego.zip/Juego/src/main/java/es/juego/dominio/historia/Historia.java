package es.juego.dominio.historia;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;

/**
 * Representa la historia narrativa completa de la partida.
 *
 * Una historia está formada por:
 *  - una lista de capítulos ya generados,
 *  - un número total de capítulos previsto para la historia,
 *  - un villano final opcional (puede no estar fijado aún).
 *
 * Contrato:
 *  - La lista devuelta por {@link #getCapitulos()} contiene los
 *    capítulos actualmente generados; no necesariamente todos.
 *
 *  - {@link #getNumeroCapitulos()} devuelve el total de capítulos
 *    que la aplicación ha planificado para esta historia. Este valor
 *    es un máximo previsto y puede ser mayor que el número actual
 *    de capítulos generados.
 *
 *  - {@link #getVillanoFinalDeHistoria()} puede devolver null en las
 *    primeras fases de creación, antes de que el flujo de aplicación
 *    asigne el villano final definitivo.
 *
 *  - La interfaz es de solo lectura para la capa de aplicación y UI.
 *    La construcción y reconstrucción del agregado se realiza mediante
 *    {@link Historias}.
 */

public interface Historia {

    /**
     * Devuelve la lista inmutable de capítulos que forman la historia.
     * El orden es el definido por la aplicación durante la creación.
     */
    List<Capitulo> getCapitulos();

    /**
     * Número total de capítulos declarados por la aplicación en el
     * momento de la creación de la historia.
     * Coincide exactamente con getCapitulos().size().
     */
    int getNumeroCapitulos();

    /**
     * Villano final de la historia completa. No tiene por qué coincidir
     * con el villano del último capítulo y puede ser generado mediante
     * un flujo independiente en la capa de aplicación.
     */
    Criatura getVillanoFinalDeHistoria();
}
