package es.juego.dominio.capitulo;

import java.util.List;

import es.juego.dominio.criatura.Criatura;
import es.juego.dominio.evento.Evento;
import es.juego.dominio.evento.TematicaEventos;

/**
 * Assembler interno para construir instancias de Capitulo
 * a partir de datos ya validados o reconstruidos.
 */
final class CapituloAssembler {

    private CapituloAssembler() {
        // no instanciable
    }

    static Capitulo desdeDatos(
            TematicaEventos tematica,
            List<Evento> eventos,
            Criatura villanoFinal
    ) {
        return new CapituloBase(tematica, eventos, villanoFinal);
    }
}
