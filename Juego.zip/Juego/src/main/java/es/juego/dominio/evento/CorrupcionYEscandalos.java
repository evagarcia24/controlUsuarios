package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum CorrupcionYEscandalos implements EnumEventoNarrativo  {

    MALETIN_SOSPECHOSO(
        "Maletín Sospechoso",
        "Encuentras un maletín abandonado lleno de documentos comprometedores que parecen asociados a un caso mediático reciente.",

        "Examinar el maletín y revisar su contenido",
        "Ignorar el maletín y alejarte con discreción",

        "El maletín se abre de golpe y una trampa de tinta explosiva te salpica de lleno.",
        "Revisas el maletín pero no encuentras nada útil ni peligroso.",
        "Descubres un documento que podría ayudarte más adelante y recuperas un vial beneficioso escondido.",
        "Encuentras un sello oficial de inmunidad temporal que te llena de energía y determinación."
    ),

    SOBRE_ANONIMO(
        "Sobre Anónimo",
        "Alguien desliza discretamente un sobre bajo tu puerta. No tiene remitente, y parece contener una denuncia delicada.",

        "Leer el sobre y analizar su contenido",
        "Dejar el sobre cerrado y descartarlo",

        "El sobre contenía polvo irritante que te provoca un fuerte estornudo y un leve mareo.",
        "El sobre solo contenía mensajes incoherentes sin valor alguno.",
        "Encuentras pistas relevantes y una nota con una pequeña recompensa útil.",
        "Descubres una credencial secreta que te otorga claridad mental y vitalidad adicional."
    ),

    INTERMEDIARIO_SOMBRIO(
        "Intermediario Sombrío",
        "Un individuo encapuchado te ofrece información privilegiada a cambio de un pequeño favor administrativo.",

        "Aceptar negociar con el intermediario",
        "Rechazar la propuesta y alejarte",

        "El intermediario te engaña y te hace perder tiempo y energía.",
        "La negociación no llega a nada, pero tampoco te perjudica.",
        "Obtienes información útil y un pequeño objeto valioso.",
        "El intermediario te revela un atajo oculto y te bendice con un impulso vital inesperado."
    ),

    CONTRATO_FANTASMA(
        "Contrato Fantasma",
        "Un contrato desaparece misteriosamente de la mesa justo cuando ibas a revisarlo. Todos juran que nunca existió.",

        "Intentar rastrear el contrato desaparecido",
        "Dejar el incidente atrás y continuar",

        "Caes en una trampa de archivadores mal apilados mientras buscas pistas.",
        "Buscas un rato sin encontrar nada concluyente.",
        "Encuentras una copia parcial del contrato con una pequeña recompensa adjunta.",
        "Localizas el contrato original en un compartimento oculto que te llena de energía renovada."
    ),

    FILTRACION_MEDIATICA(
        "Filtración Mediática",
        "Una noticia explosiva sobre corrupción estalla en los medios y afecta a todo el edificio.",

        "Investigar la fuente de la filtración",
        "Evitar involucrarte y avanzar por otra zona",

        "La prensa te acorrala y te ves envuelto en una discusión agotadora.",
        "Observas el caos a distancia sin que te afecte directamente.",
        "Descubres la fuente real y recibes un pequeño obsequio de agradecimiento.",
        "La fuente filtrada te conduce a un refugio seguro donde recuperas vitalidad y enfoque."
    ),

    FONDOS_DESVIADOS(
        "Fondos Desviados",
        "Te topas con un cuadro contable que no cuadra y revela movimientos sospechosos de dinero público.",

        "Intentar descifrar y corregir las cuentas",
        "Decidir no implicarte y retirarte",

        "Mientras investigas, un archivador cae y te golpea.",
        "No logras aclarar nada, pero tampoco empeoras la situación.",
        "Encuentras un recibo oculto con una recompensa inesperada.",
        "Descubres la ruta completa del desvío y te invade un poderoso entusiasmo vital."
    ),

    TESTIGO_CLAVE(
        "Testigo Clave",
        "Un testigo esencial para un escándalo está escondido detrás de una pila de documentos, temiendo por su seguridad.",

        "Hablar con el testigo e intentar convencerlo",
        "No intervenir y continuar sin involucrarte",

        "El testigo se asusta y tropieza contigo, causándote un golpe accidental.",
        "El testigo no colabora, pero la situación se mantiene estable.",
        "El testigo te da información valiosa y un pequeño frasco de apoyo.",
        "Ganas la confianza total del testigo, que te revela un secreto que revitaliza tu espíritu."
    ),

    CASO_ENTERRADO(
        "Caso Enterrado",
        "Descubres un expediente extremadamente grueso enterrado bajo capas de otros casos olvidados.",

        "Intentar desenterrar el caso para revisarlo",
        "Dejarlo en el olvido y alejarte del caos documental",

        "El peso de los documentos te hace perder el equilibrio, provocándote una torcedura leve.",
        "Solo logras sacar un par de papeles sin importancia.",
        "Encuentras una sección relevante con una pequeña recompensa adherida.",
        "Desentierras el caso completo y una antigua nota de felicitación te llena de vigor."
    ),

    AGENTE_DOBLE(
        "Agente Doble",
        "Un funcionario que conocías actúa de forma sospechosa, y parece trabajar para dos bandos al mismo tiempo.",

        "Enfrentarlo directamente",
        "Evitar contacto y observar desde lejos",

        "El agente te tiende una pequeña trampa que te causa un contratiempo físico.",
        "El agente no revela nada y se marcha sin consecuencias.",
        "Obtienes una pista crucial junto con un objeto útil.",
        "El agente, impresionado por tu valentía, te regala un amuleto que refuerza tu energía."
    ),

    DESPACHO_SECRETO(
        "Despacho Secreto",
        "Descubres una puerta entreabierta que conduce a un despacho que no figura en ningún plano oficial.",

        "Explorar el despacho secreto",
        "Cerrarlo discretamente y seguir tu camino",

        "Activas una trampa de seguridad que te hiere ligeramente.",
        "El despacho no contiene nada relevante aparte de polvo.",
        "Encuentras documentos útiles y un frasco de recuperación.",
        "Descubres un compartimento oculto lleno de luz que te infunde energía vital."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    CorrupcionYEscandalos(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
