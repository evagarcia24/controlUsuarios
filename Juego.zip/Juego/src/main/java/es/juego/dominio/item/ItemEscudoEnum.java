package es.juego.dominio.item;

import lombok.Getter;

@Getter
enum ItemEscudoEnum implements Item {

    // NIVEL 1 (1..11)
    ESC_LV1_01("Carpeta medio vacía de ventanilla", 1),
    ESC_LV1_02("Post-it con anotación dudosa", 1),
    ESC_LV1_03("Sobre común arrugado", 1),
    ESC_LV1_04("Fundita de gafas del bedel", 1),
    ESC_LV1_05("Hoja de reclamación sin copias", 1),
    ESC_LV1_06("Manual de bienvenida que nadie lee", 1),
    ESC_LV1_07("Cartel de turno apagado", 1),
    ESC_LV1_08("Folio grapado de mala manera", 1),
    ESC_LV1_09("Etiqueta adhesiva sin pegamento", 1),
    ESC_LV1_10("Portafirmas improvisado", 1),

    // NIVEL 2
    ESC_LV2_01("Carpeta plastificada de plazo vencido", 2),
    ESC_LV2_02("Separadores de expediente olvidado", 2),
    ESC_LV2_03("Archivador de quejas dormidas", 2),
    ESC_LV2_04("Contrato fotocopiado veinte veces", 2),
    ESC_LV2_05("Libro de actas con páginas sueltas", 2),
    ESC_LV2_06("Protocolo de actuación desfasado", 2),
    ESC_LV2_07("Hoja sellada con tinta diluida", 2),
    ESC_LV2_08("Reglamento de comunidad amarillento", 2),
    ESC_LV2_09("Copia de denuncia mal recortada", 2),
    ESC_LV2_10("Tríptico municipal de 1998", 2),

    // NIVEL 3
    ESC_LV3_01("Blindaje de fotocopiadora atascada", 3),
    ESC_LV3_02("Documento sellado con mala intención", 3),
    ESC_LV3_03("Legajo con cintas mal anudadas", 3),
    ESC_LV3_04("Memoria técnica incompleta", 3),
    ESC_LV3_05("Certificado de empadronamiento doblado", 3),
    ESC_LV3_06("Libro de registro con tapas rotas", 3),
    ESC_LV3_07("Anexo de informe sin anexos", 3),
    ESC_LV3_08("Carpeta de subdirección en reserva", 3),
    ESC_LV3_09("Tabla comparativa sin números", 3),
    ESC_LV3_10("Recomendación oficial descafeinada", 3),

    // NIVEL 4
    ESC_LV4_01("Reglamento autonómico ambiguo", 4),
    ESC_LV4_02("Manual de transparencia opaco", 4),
    ESC_LV4_03("Estatuto interno en reforma eterna", 4),
    ESC_LV4_04("Carpeta naranja de comité funcional", 4),
    ESC_LV4_05("Informe de impacto con lagunas", 4),
    ESC_LV4_06("Protocolo de riesgo improbable", 4),
    ESC_LV4_07("Copia compulsada en mal estado", 4),
    ESC_LV4_08("Directriz contradictoria", 4),
    ESC_LV4_09("Documento confidencial filtrado", 4),
    ESC_LV4_10("Acta extraordinaria sin firmas", 4),

    // NIVEL 5
    ESC_LV5_01("Blindaje de auditoría superficial", 5),
    ESC_LV5_02("Reglamento sectorial disperso", 5),
    ESC_LV5_03("Manual de procedimiento redundante", 5),
    ESC_LV5_04("Carpeta blindada del viejo archivo", 5),
    ESC_LV5_05("Legislación aplicada con pereza", 5),
    ESC_LV5_06("Informe de comisión paralela", 5),
    ESC_LV5_07("Expediente resistente al fuego lento", 5),
    ESC_LV5_08("Resumen ejecutivo incomprensible", 5),
    ESC_LV5_09("Anuario de estadísticas alteradas", 5),
    ESC_LV5_10("Cuaderno de coordinación hermético", 5),

    // NIVEL 6
    ESC_LV6_01("Carpeta blindada con sello triple", 6),
    ESC_LV6_02("Acta reforzada de uso interno", 6),
    ESC_LV6_03("Dossier clasificado con candado", 6),
    ESC_LV6_04("Libro gordo de jurisprudencia cambiante", 6),
    ESC_LV6_05("Plegable jurídico de alta densidad", 6),
    ESC_LV6_06("Directiva interministerial robusta", 6),
    ESC_LV6_07("Protocolo reforzado de emergencia", 6),
    ESC_LV6_08("Reglamento blindado contra recursos", 6),
    ESC_LV6_09("Documento estratégico hermético", 6),
    ESC_LV6_10("Acuerdo sectorial sellado dos veces", 6),

    // NIVEL 7
    ESC_LV7_01("Código administrativo reforzado", 7),
    ESC_LV7_02("Blindaje de normativa orgánica", 7),
    ESC_LV7_03("Compendio jurídico cargado", 7),
    ESC_LV7_04("Escudo de dictamen vinculante", 7),
    ESC_LV7_05("Carpeta acorazada del gabinete", 7),
    ESC_LV7_06("Manual de control inapelable", 7),
    ESC_LV7_07("Libro maestro de subcomisión", 7),
    ESC_LV7_08("Reglamento soberano inalterable", 7),
    ESC_LV7_09("Acta blindada del comité central", 7),
    ESC_LV7_10("Protocolo supremo sellado", 7),

    // NIVEL 8
    ESC_LV8_01("Escudo de normativa constitucional", 8),
    ESC_LV8_02("Carpeta de Estado hermética", 8),
    ESC_LV8_03("Libro magistral del consejo asesor", 8),
    ESC_LV8_04("Compendio blindado de supervisión", 8),
    ESC_LV8_05("Reglamento de control absoluto", 8),
    ESC_LV8_06("Dictamen inamovible reforzado", 8),
    ESC_LV8_07("Memoria institucional acorazada", 8),
    ESC_LV8_08("Protocolo supremo iterado", 8),
    ESC_LV8_09("Carta de garantías reforzada", 8),
    ESC_LV8_10("Legislación endurecida del consejo", 8),

    // NIVEL 9
    ESC_LV9_01("Blindaje de resolución irrevocable", 9),
    ESC_LV9_02("Constitución parcial reforzada", 9),
    ESC_LV9_03("Libro inquebrantable de jurisprudencia", 9),
    ESC_LV9_04("Escudo supremo de legalidad total", 9),
    ESC_LV9_05("Marco regulatorio acorazado", 9),
    ESC_LV9_06("Protocolo judicial impenetrable", 9),
    ESC_LV9_07("Código de integridad indestructible", 9),
    ESC_LV9_08("Compendio normativo absoluto", 9),
    ESC_LV9_09("Directriz mayor pétrea", 9),
    ESC_LV9_10("Acta constitucional reforzada", 9),

    // NIVEL 10
    ESC_LV10_01("Constitución acorazada en titanio burocrático", 10),
    ESC_LV10_02("Libro sagrado de la democracia recursiva", 10),
    ESC_LV10_03("Escudo absoluto de legalidad eterna", 10),
    ESC_LV10_04("Compendio supremo de doctrina estatal", 10),
    ESC_LV10_05("Marco invulnerable de orden institucional", 10),
    ESC_LV10_06("Protocolo perfecto de supervisión total", 10),
    ESC_LV10_07("Códice fundacional blindado", 10),
    ESC_LV10_08("Decreto pétreo de máxima autoridad", 10),
    ESC_LV10_09("Legajo definitivo de estabilidad perpetua", 10),
    ESC_LV10_10("Acta primordial de orden eterno", 10),
	
    // NIVEL 11 limitaciones sociales, cognitivas y humanas)
	ESC_LV11_01("Manuscrito de duda existencial", 11),
	ESC_LV11_02("Tratado incompleto sobre la mente humana", 11),
	ESC_LV11_03("Compendio de prejuicios arraigados", 11),
	ESC_LV11_04("Mapa difuso de identidades colectivas", 11),
	ESC_LV11_05("Manual de percepción subjetiva fragmentada", 11),
	ESC_LV11_06("Cuaderno de paradojas morales", 11),
	ESC_LV11_07("Esquema de sesgos cognitivos", 11),
	ESC_LV11_08("Glosario de errores de juicio", 11),
	ESC_LV11_09("Manifiesto de voluntad contradictoria", 11),
	ESC_LV11_10("Compendio de limitaciones humanas universales", 11);

    private final String nombre;
    private final int puntos;

    ItemEscudoEnum(String nombre, int puntos) {
        this.nombre = nombre;
        this.puntos = puntos;
    }

	@Override
	public int getNivel() {
		return getPuntos();
	}
	
}
