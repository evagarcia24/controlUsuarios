package es.juego.dominio.dado;

/**
 * El lanzador automático ejecuta la tirada directamente.
 */
final class LanzadorAutomatico implements Lanzador {

    @Override
    public int lanzar(Caras caras) {
        return caras.lanzar();
    }
}
