package es.juego.dominio.item;

import lombok.Getter;

@Getter
enum ItemArmaEnum implements Item {

    // NIVEL 1 (1..11)
    ARM_LV1_01("Lápiz sin punta", 1),
    ARM_LV1_02("Taza de café frío", 1),
    ARM_LV1_03("Grapadora sin grapas", 1),
    ARM_LV1_04("Carpeta medio rota", 1),
    ARM_LV1_05("Subrayador seco", 1),
    ARM_LV1_06("Post-it pegado del revés", 1),
    ARM_LV1_07("Pliego arrugado", 1),
    ARM_LV1_08("Folleto desactualizado", 1),
    ARM_LV1_09("Bolsa de mercadillo con agujeros", 1),
    ARM_LV1_10("Tapa de archivador suelta", 1),

    // NIVEL 2
    ARM_LV2_01("Bolígrafo que falla", 2),
    ARM_LV2_02("Carpeta con clip torcido", 2),
    ARM_LV2_03("Manual básico ilegible", 2),
    ARM_LV2_04("Taza con mensaje motivacional falso", 2),
    ARM_LV2_05("Regla de plástico doblada", 2),
    ARM_LV2_06("Agenda de año pasado", 2),
    ARM_LV2_07("Hoja grapada torcida", 2),
    ARM_LV2_08("Panfleto electoral rancio", 2),
    ARM_LV2_09("Cartera de repartidor cansado", 2),
    ARM_LV2_10("Micrófono apagado", 2),

    // NIVEL 3
    ARM_LV3_01("Puntero láser barato", 3),
    ARM_LV3_02("Sellador sin tinta", 3),
    ARM_LV3_03("Archivador inflado", 3),
    ARM_LV3_04("Cartera de expediente gastado", 3),
    ARM_LV3_05("Cafetera portátil defectuosa", 3),
    ARM_LV3_06("Bolso de mesa electoral", 3),
    ARM_LV3_07("Manual de protocolo contradictorio", 3),
    ARM_LV3_08("Sobre acolchado sospechoso", 3),
    ARM_LV3_09("Carrito cojo de pasillo", 3),
    ARM_LV3_10("Caballete de rueda floja", 3),

    // NIVEL 4
    ARM_LV4_01("Sello de aprobación dudosa", 4),
    ARM_LV4_02("Micrófono con eco eterno", 4),
    ARM_LV4_03("Cafetera con café concentrado", 4),
    ARM_LV4_04("Libro de actas pesado", 4),
    ARM_LV4_05("Carpeta metálica oxidada", 4),
    ARM_LV4_06("Extintor descargado", 4),
    ARM_LV4_07("Maza de mesa electoral", 4),
    ARM_LV4_08("Portafirmas reforzado", 4),
    ARM_LV4_09("Atril ruidoso", 4),
    ARM_LV4_10("Sobre lacrado de duda pública", 4),

    // NIVEL 5
    ARM_LV5_01("Cafetera industrial traqueteante", 5),
    ARM_LV5_02("Sello de triple validación", 5),
    ARM_LV5_03("Martillo sindical", 5),
    ARM_LV5_04("Carrito de supermercado agresivo", 5),
    ARM_LV5_05("Bolsa de documentos blindada", 5),
    ARM_LV5_06("Micrófono con feedback moderado", 5),
    ARM_LV5_07("Archivador con bisagra rota", 5),
    ARM_LV5_08("Libro de normativas pesadas", 5),
    ARM_LV5_09("Palo de pancarta reforzada", 5),
    ARM_LV5_10("Atril ministerial robusto", 5),

    // NIVEL 6
    ARM_LV6_01("Carro metálico de ventanilla", 6),
    ARM_LV6_02("Sello de burocracia pesada", 6),
    ARM_LV6_03("Micrófono parlamentario defectuoso", 6),
    ARM_LV6_04("Libro de leyes subrayado en exceso", 6),
    ARM_LV6_05("Expediente de 500 páginas", 6),
    ARM_LV6_06("Palo telescópico de protesta", 6),
    ARM_LV6_07("Manivela de urna temblorosa", 6),
    ARM_LV6_08("Cartera blindada del secretario", 6),
    ARM_LV6_09("Puntero láser industrial", 6),
    ARM_LV6_10("Maza administrativa pesada", 6),

    // NIVEL 7
    ARM_LV7_01("Micrófono de rueda de prensa", 7),
    ARM_LV7_02("Carpeta acorazada autonómica", 7),
    ARM_LV7_03("Libro de legislatura completa", 7),
    ARM_LV7_04("Cuaderno de actas reforzado", 7),
    ARM_LV7_05("Palo de pancarta endurecido", 7),
    ARM_LV7_06("Sello de imposición absoluta", 7),
    ARM_LV7_07("Atril de oratoria contundente", 7),
    ARM_LV7_08("Libro de gastos reservados", 7),
    ARM_LV7_09("Cartera ministerial robusta", 7),
    ARM_LV7_10("Dossier blindado indestructible", 7),

    // NIVEL 8
    ARM_LV8_01("Libro constitucional de bolsillo", 8),
    ARM_LV8_02("Sello institucional supremo", 8),
    ARM_LV8_03("Carpeta estatal blindada", 8),
    ARM_LV8_04("Micrófono omnidireccional crítico", 8),
    ARM_LV8_05("Código legislativo devastador", 8),
    ARM_LV8_06("Acta suprema de impacto", 8),
    ARM_LV8_07("Pergamino de mandato férreo", 8),
    ARM_LV8_08("Libro maestro de reglamentos", 8),
    ARM_LV8_09("Carpeta soberana con cierre mágico", 8),
    ARM_LV8_10("Panfleto radical extremadamente denso", 8),

    // NIVEL 9
    ARM_LV9_01("Libro de jurisprudencia eterna", 9),
    ARM_LV9_02("Maza parlamentaria contundente", 9),
    ARM_LV9_03("Cartera blindada presidencial", 9),
    ARM_LV9_04("Código supremo de decretos", 9),
    ARM_LV9_05("Sello irrompible de máxima autoridad", 9),
    ARM_LV9_06("Micrófono intimidante de debate", 9),
    ARM_LV9_07("Libro de subcomisión absoluta", 9),
    ARM_LV9_08("Carpeta acorazada de alta seguridad", 9),
    ARM_LV9_09("Legajo de impacto devastador", 9),
    ARM_LV9_10("Manifiesto pétreo", 9),

    // NIVEL 10 
    ARM_LV10_01("Código constitucional definitivo", 10),
    ARM_LV10_02("Vara soberana del parlamento", 10),
    ARM_LV10_03("Sello arcano de Estado profundo", 10),
    ARM_LV10_04("Libro épico de superlegislación", 10),
    ARM_LV10_05("Acta primordial imborrable", 10),
    ARM_LV10_06("Maza suprema institucional", 10),
    ARM_LV10_07("Carpeta invulnerable de Estado", 10),
    ARM_LV10_08("Micrófono ancestral de oratoria total", 10),
    ARM_LV10_09("Tomazo de burocracia eterna", 10),
    ARM_LV10_10("Libro del decreto final", 10),
	
	// NIVEL 11 Psiquis, lenguaje, conflicto interno, naturaleza humana
	ARM_LV11_01("Concepto afilado de disonancia cognitiva", 11),
	ARM_LV11_02("Martillo de impulso irracional", 11),
	ARM_LV11_03("Punzón de memoria selectiva", 11),
	ARM_LV11_04("Cuchilla de introspección dolorosa", 11),
	ARM_LV11_05("Báculo de percepción distorsionada", 11),
	ARM_LV11_06("Lanza de duda interior", 11),
	ARM_LV11_07("Maza de tensión social acumulada", 11),
	ARM_LV11_08("Daga de contradicción moral", 11),
	ARM_LV11_09("Sable de miedo arquetípico", 11),
	ARM_LV11_10("Artefacto de conflicto psicológico profundo", 11);


    private final String nombre;
    private final int puntos;

    ItemArmaEnum(String nombre, int puntos) {
        this.nombre = nombre;
        this.puntos = puntos;
    }

	@Override
	public int getNivel() {
		return getPuntos();
	}
	
}
