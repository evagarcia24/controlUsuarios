package es.juego.dominio.dado;

/**
 * Dado de 21 caras (1-21).
 */
final class Caras21 implements Caras {

    @Override
    public int lanzar() {
        return (int) (Math.random() * 21) + 1;
    }
}
