package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum InstitucionesDeformadas implements EnumEventoNarrativo  {

    BUROCRATA_CON_TENTACULOS(
        "Burócrata con Tentáculos",
        "Una figura institucional mutada extiende varios tentáculos administrativos intentando sellar documentos sin parar.",

        "Intentar entender su método y colaborar",
        "Retroceder lentamente y evitar involucrarte",

        "Un tentáculo se mueve bruscamente y te golpea con un sello metálico.",
        "El burócrata tentacular no parece notar tu presencia y sigues igual.",
        "Logras coordinar un sello con él y recibes un pequeño obsequio abandonado.",
        "El ser tentacular reconoce tu eficiencia y te transmite una ola de energía revitalizante."
    ),

    CONSEJO_FRAGMENTADO(
        "Consejo Fragmentado",
        "Un grupo de altos cargos aparece dividido en hologramas desincronizados, discutiendo entre sí como si fueran versiones rotas de la misma persona.",

        "Intentar unir sus opiniones para obtener claridad",
        "Evitar el debate y salir silenciosamente",

        "Los hologramas explotan en ruido y te aturden durante un instante.",
        "Los hologramas no llegan a ninguna conclusión y simplemente sigues adelante.",
        "Logras sincronizarlos brevemente y uno de ellos te entrega un pequeño apoyo.",
        "Los fragmentos institucionales se alinean y te envían un pulso de energía benéfica."
    ),

    ASCENSOR_DE_MANDATOS(
        "Ascensor de Mandatos",
        "Un ascensor institucional muestra pisos imposibles y cambia sus botones según intereses ocultos.",

        "Intentar descifrar el patrón del ascensor",
        "Tomar las escaleras y evitar el mecanismo",

        "El ascensor se abre bruscamente y te golpea con una puerta defectuosa.",
        "El ascensor se limita a emitir un zumbido, sin consecuencias.",
        "Descifras momentáneamente el patrón y encuentras un pequeño recurso olvidado.",
        "El ascensor se ilumina de forma perfecta y te bendice con energía renovada."
    ),

    SALA_DECRETOS_VIVIENTES(
        "Sala de Decretos Vivientes",
        "Los decretos enmarcados de la sala cobran vida y discuten entre sí sobre su propia legalidad.",

        "Intentar mediar entre los decretos",
        "Ignorarlos y pasar por la sala lo más rápido posible",

        "Los decretos se abalanzan sobre ti y te golpean con marcos rígidos.",
        "Los decretos te ignoran mientras siguen discutiendo entre ellos.",
        "Uno de los decretos se muestra receptivo y te ofrece un pequeño favor.",
        "Los decretos se alinean ante tu presencia y emiten una luz que fortalece tu vitalidad."
    ),

    COMITE_DISTORSIONADO(
        "Comité Distorsionado",
        "Un comité entero aparece duplicado y distorsionado en dos mesas paralelas, debatiendo decisiones contradictorias.",

        "Intentar reconciliar las dos mesas",
        "Evitar el comité y dar un rodeo institucional",

        "Un miembro distorsionado golpea accidentalmente una carpeta que te alcanza.",
        "Ambos comités discuten sin parar y no ocurre nada relevante.",
        "Consigues que las mesas lleguen a un acuerdo menor y recibes un pequeño reconocimiento.",
        "Las dos versiones del comité convergen y te otorgan un impulso vital extraordinario."
    ),

    CIRCULO_DE_FUNCIONES(
        "Círculo de Funciones",
        "Un grupo de funcionarios gira en círculo pasándose responsabilidades de forma infinita.",

        "Romper el ciclo preguntando por el origen",
        "Rodear al grupo sin intervenir",

        "Un funcionario tropieza contigo mientras gira sin control.",
        "El círculo continúa sin alterarse y no te afecta.",
        "El ciclo se detiene un instante y recibes un pequeño refuerzo.",
        "El grupo se sincroniza un breve momento y te transmite una energía restauradora."
    ),

    VENTANILLA_MULTIDIMENSIONAL(
        "Ventanilla Multidimensional",
        "Una ventanilla aparece y desaparece en diferentes dimensiones del pasillo, mostrando sellos imposibles de reproducir.",

        "Intentar interactuar con la ventanilla cuando se materializa",
        "Esperar a que desaparezca del todo y seguir tu camino",

        "La ventanilla se materializa sobre tu mano y te causa un impacto doloroso.",
        "La ventanilla parpadea sin causarte daño.",
        "Logras obtener un sello exótico con un pequeño beneficio añadido.",
        "Accedes a una dimensión administrativa superior que te llena de energía vital."
    ),

    ARCHIVO_QUE_GRITA(
        "Archivo que Grita",
        "Un archivo vivo emite gritos cada vez que alguien intenta abrirlo, como si se resistiera a ser leído.",

        "Intentar calmar al archivo para abrirlo",
        "Abandonar el archivo gritón",

        "El archivo grita tan fuerte que te hace retroceder y te causa un malestar físico.",
        "El archivo se limita a gemir suavemente sin mayores consecuencias.",
        "El archivo se deja abrir y contiene un pequeño recurso útil.",
        "El archivo canta en armonía contigo y desata un flujo de energía positiva."
    ),

    PROTOCOLO_CAMBIANTE(
        "Protocolo Cambiante",
        "Un cartel institucional cambia de reglas en tiempo real cada vez que lo miras.",

        "Intentar memorizar o descifrar el patrón",
        "Dejar de mirarlo y continuar andando",

        "Un cambio brusco del cartel te provoca un sobresalto que te desequilibra.",
        "El cartel cambia sin afectar tu camino.",
        "Logras anticipar un patrón y encuentras una pequeña ventaja oculta.",
        "El cartel revela una regla dorada que mejora tu vitalidad interior."
    ),

    MESA_DE_MANDATOS(
        "Mesa de Mandatos",
        "Una mesa institucional emite órdenes contradictorias por sí sola, moviendo papeles con voluntad propia.",

        "Intentar ordenar los papeles",
        "Esquivar la mesa y continuar tu recorrido",

        "Un papel afilado sale despedido y te provoca un corte leve.",
        "La mesa ignora tu presencia y sigue moviendo documentos.",
        "Logras colocar algunos papeles y encuentras un pequeño obsequio.",
        "La mesa se calma ante ti y te otorga una oleada de vitalidad."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    InstitucionesDeformadas(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
