package es.juego.dominio.dado;

/**
 * Dado de 10 caras (1-10).
 */
final class Caras10 implements Caras {

    @Override
    public int lanzar() {
        return (int) (Math.random() * 10) + 1;
    }
}
