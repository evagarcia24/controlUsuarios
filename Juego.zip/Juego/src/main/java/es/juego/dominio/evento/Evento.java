package es.juego.dominio.evento;

/**
 * Representa un evento narrativo completamente preparado para jugar.
 * Es inmutable. No contiene efectos ni reglas.
 */
public interface Evento {

    String getTitulo();
    String getDescripcion();

    String getOpcion1();
    String getOpcion2();

    String getTextoFracaso();
    String getTextoNeutro();
    String getTextoExito();
    String getTextoVidaPlus();
}
