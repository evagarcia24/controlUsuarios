package es.juego.dominio.item;

import java.util.Collection;
import java.util.List;

/**
 * Fachada de utilidades de alto nivel para operar con los catálogos de ítems
 * del dominio (armas, escudos y pociones). Todas las implementaciones
 * concretas están modeladas como enums internos del paquete y expuestas a
 * través de la interfaz sellada {@link Item}.
 *
 * <p>Esta clase concentra operaciones comunes que las capas superiores pueden
 * necesitar: consultas por nivel, filtrado por exclusión y reconstrucción de
 * ítems desde nombres de constantes enum.
 *
 * <p>La implementación delega toda la lógica interna en {@link ItemFactory},
 * garantizando una única fuente de verdad y manteniendo el modelo cerrado y
 * coherente.
 */
public final class Items {

	private Items() {
	}

    /**
     * Devuelve todos los ítems del catálogo de armas cuyo nivel coincide con
     * {@code nivel}.
     *
     * @param nivel nivel por el cual se filtran los ítems
     * @return lista de armas del nivel indicado
     */
	public static List<Item> armasPorNivel(int nivel) {
		return ItemFactory.listaPorNivel(ItemArmaEnum.class, nivel);
	}

    /**
     * Devuelve todos los ítems del catálogo de escudos cuyo nivel coincide con
     * {@code nivel}.
     *
     * @param nivel nivel por el cual se filtran los ítems
     * @return lista de escudos del nivel indicado
     */
	public static List<Item> escudosPorNivel(int nivel) {
		return ItemFactory.listaPorNivel(ItemEscudoEnum.class, nivel);
	}

    /**
     * Devuelve todas las pociones curativas cuyo nivel coincide con
     * {@code nivel}.
     *
     * @param nivel nivel por el cual se filtran las pociones
     * @return lista de pociones del nivel indicado
     */
	public static List<Item> pocionesPorNivel(int nivel) {
		return ItemFactory.listaPorNivel(ItemPocionCurativaEnum.class, nivel);
	}

    /**
     * Devuelve los ítems del mismo tipo concreto (arma, escudo o poción) y del
     * mismo nivel que los presentes en {@code excluir}, omitiendo aquellos que ya
     * aparecen en esa colección.
     *
     * <p>El tipo y nivel del catálogo se infieren a partir del primer elemento
     * de {@code excluir}. Todos los ítems de la colección deben pertenecer al
     * mismo catálogo y nivel.
     *
     * @param excluir colección de ítems que actúan como referencia y que deben
     *                eliminarse del resultado
     * @return lista de ítems del mismo catálogo y nivel que no se encuentran en
     *         {@code excluir}
     * @throws IllegalArgumentException si {@code excluir} es null, está vacía
     *                                  o contiene un tipo no reconocido
     */
	public static List<Item> disponiblesExcluyendo(Collection<Item> excluir) {

	    if (excluir == null || excluir.isEmpty()) {
	        throw new IllegalArgumentException("La colección no puede estar vacía");
	    }

	    Item muestra = excluir.iterator().next();
	    int nivel = muestra.getNivel();

	    // Switch clásico: sólo por clase concreta
	    if (muestra instanceof ItemArmaEnum) {
	        return ItemFactory.disponiblesExcluyendo(ItemArmaEnum.class, nivel, excluir);
	    }

	    if (muestra instanceof ItemEscudoEnum) {
	        return ItemFactory.disponiblesExcluyendo(ItemEscudoEnum.class, nivel, excluir);
	    }

	    if (muestra instanceof ItemPocionCurativaEnum) {
	        return ItemFactory.disponiblesExcluyendo(ItemPocionCurativaEnum.class, nivel, excluir);
	    }

	    throw new IllegalArgumentException(
	            "Tipo de item desconocido: " + muestra.getClass().getName());
	}
	

    /**
     * Reconstruye ítems del dominio a partir de una lista de nombres de
     * constantes enum.
     *
     * <p>Este método se utiliza al cargar ítems desde almacenamiento (BD, JSON,
     * serialización) donde únicamente se conserva el nombre exacto de la
     * constante. La inferencia del catálogo se realiza automáticamente a partir
     * del prefijo del identificador:
     * <ul>
     *   <li>{@code ARM_} → armas</li>
     *   <li>{@code ESC_} → escudos</li>
     *   <li>{@code POC_} → pociones</li>
     * </ul>
     *
     * @param nombresEnum lista de nombres de constantes enum (por ejemplo:
     *                    {@code "ARM_LV3_04"})
     * @return lista de ítems reales del dominio reconstruidos desde sus nombres
     */
    public static List<Item> reconstruir(List<String> nombresEnum) {
        return ItemFactory.reconstruirListaSoloConNombres(nombresEnum);
    }

}
