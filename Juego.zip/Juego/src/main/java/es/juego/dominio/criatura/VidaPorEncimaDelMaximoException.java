package es.juego.dominio.criatura;

@SuppressWarnings("serial")
final class VidaPorEncimaDelMaximoException extends RuntimeException {
    VidaPorEncimaDelMaximoException(String msg) {
        super(msg);
    }
}
