package es.juego.dominio.nombre;

import lombok.Getter;

@Getter
enum NombreVillanoEnum {

    // 1 — Burocracia disfuncional
    BUROCRACIA_DISFUNCIONAL(new String[]{
        "Burocracia Viviente",
        "Caso de Corrupción",
        "Bestia de Hacienda",
        "Ley Mordaza",
        "Monstruo Mediático",
        "Fantasma del Déficit",
        "Titán de la Deuda Pública",
        "Juez Implacable",
        "Sombra del Sindicalismo Radical",
        "Espectro del Desempleo"
    }),

    // 2 — Corrupción y escándalos
    CORRUPCION_Y_ESCANDALOS(new String[]{
        "Gürtel",
        "ERE Andalucía",
        "Púnica",
        "Kitchen",
        "Malversación Etérea",
        "Trama de los Sobres",
        "Red Clientelar",
        "Manipulador de Contratos",
        "Conseguidor",
        "Fantasma de las Subvenciones"
    }),

    // 3 — Instituciones deformadas
    INSTITUCIONES_DEFORMADAS(new String[]{
        "Defensor de los Papeleos",
        "Inspector Impecable",
        "Fiscal Sombrío",
        "Administrador Opaco",
        "Consejo del Olvido",
        "Mesa de Diálogo Eternizada",
        "Agencia del Inmovilismo",
        "Tribunal Variable",
        "Comisión del Retraso Eterno",
        "Secretario Inflexible"
    }),

    // 4 — Economía, crisis y mercado laboral
    ECONOMIA_Y_CRISIS(new String[]{
        "Burbuja Inmobiliaria",
        "Preferentista",
        "Mercado Negro",
        "Banco Resucitado",
        "Rescate Financiero",
        "Paro Juvenil",
        "Contrato Basura",
        "Subida del IPC",
        "Crisis de 2008",
        "Reforma Laboral Sombría"
    }),

    // 5 — Medios y comunicación
    MEDIOS_Y_COMUNICACION(new String[]{
        "Titular Tendencioso",
        "Bulos Virales",
        "Editorial Sesgado",
        "Filtraciones Interesadas",
        "Encuesta Misteriosa",
        "Agenda Oculta",
        "Manipulador de Debate",
        "Panel de Distorsión",
        "Ruido Informativo",
        "Propagador del Miedo"
    }),

    // 6 — Infraestructuras deficientes
    INFRAESTRUCTURAS_DEFICIENTES(new String[]{
        "Obras Eternas",
        "Autovía Fantasma",
        "Aeropuerto sin Aviones",
        "AVE con Sobrecoste",
        "Puente Inacabado",
        "Rotonda Infinita",
        "Fantasma Logístico",
        "Pelotón de Subcontratas",
        "Contrato Anulado",
        "Edificio Irregular"
    }),

    // 7 — Ideología y tensiones territoriales
    IDEOLOGIA_Y_TENSIONES(new String[]{
        "Soberanismo Envolvente",
        "Polarizador",
        "Extremista Volátil",
        "Populismo Embrujador",
        "Guerra Cultural",
        "Tensión Territorial",
        "Marea Ideológica",
        "Comité de Expertos Inexistente",
        "Identidad Fragmentada",
        "Presión Callejera"
    }),

    // 8 — Servicios públicos colapsados
    SERVICIOS_PUBLICOS_COLAPSADOS(new String[]{
        "Lista de Espera Infinita",
        "Aula Masificada",
        "Recortes Sociales",
        "Colapso de Servicios",
        "Gestión Caótica",
        "Turnos Eternos",
        "Brecha Digital",
        "Falta de Recursos",
        "Burofax Fallido",
        "Papeleo Telemático"
    }),
	
	// 9 — Metafísica sarcástica y limitaciones humanas
	METAFISICA_SARCASMO(new String[]{
	    "Entropía Bipeda",
	    "Contradicción con Patas",
	    "Ego Inestable",
	    "Sombra de la Autocrítica",
	    "Avatar del Autoengaño",
	    "Cicatriz Emocional Ambulante",
	    "Réplica de la Duda Interna",
	    "Ruido Mental Permanente",
	    "Espiral de Pensamientos Rotos",
	    "Reflejo Imperfecto del Yo"
	});

    private final String[] tipos;

    NombreVillanoEnum(String[] tipos) {
        this.tipos = tipos;
    }
}
