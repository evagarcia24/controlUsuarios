package es.juego.dominio.evento;

/**
 * Contrato común para todos los enums temáticos de eventos.
 * Define los getters narrativos que cada uno expone.
 */
interface EnumEventoNarrativo {

    String getTitulo();
    String getDescripcion();

    String getOpcion1();
    String getOpcion2();

    String getTextoFracaso();
    String getTextoNeutro();
    String getTextoExito();
    String getTextoVidaPlus();
}
