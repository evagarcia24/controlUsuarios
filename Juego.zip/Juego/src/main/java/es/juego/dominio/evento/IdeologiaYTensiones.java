package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum IdeologiaYTensiones implements EnumEventoNarrativo  {

    DEBATE_EN_LLAMA(
        "Debate en Llama",
        "Dos grupos enfrentados discuten tan fuerte que parecen lanzar calor ideológico al ambiente.",

        "Intentar mediar entre ambos grupos",
        "Evitar el debate y retirarte en silencio",

        "Una onda de gritos te aturde y te provoca un golpecito doloroso.",
        "Ambos grupos te ignoran mientras continúan discutiendo.",
        "Consigues calmar un instante la tensión y recibes un pequeño agradecimiento.",
        "Tu intervención crea una tregua temporal que te llena de energía vital."
    ),

    MURAL_POLARIZADO(
        "Mural Polarizado",
        "Un mural institucional cambia de símbolo cada pocos segundos, reflejando posiciones opuestas sin descanso.",

        "Intentar estabilizar el símbolo dominante",
        "No implicarte y continuar tu camino",

        "El mural emite una ráfaga que te desequilibra.",
        "Los símbolos cambian sin afectarte.",
        "Logras fijar un símbolo por un instante y encuentras un objeto útil.",
        "Descifras el patrón y el mural proyecta una luz revitalizadora."
    ),

    DISCURSO_INTERMINABLE(
        "Discurso Interminable",
        "Un orador sobre un podio parece atrapado en un discurso cíclico que no avanza y altera el ambiente.",

        "Intentar ayudar al orador a romper el ciclo",
        "Evitar el podio y pasar por un lateral",

        "Una vibración del micrófono te sacude la mano dolorosamente.",
        "El orador sigue hablando sin consecuencia alguna.",
        "Logras interrumpirlo un instante y te entrega un pequeño detalle.",
        "El orador sale del trance y te dedica una bendición que aumenta tu vitalidad."
    ),

    SIMBOLO_DIVIDIDO(
        "Símbolo Dividido",
        "Un gran símbolo político aparece partido por la mitad, vibrando como si cada parte quisiera imponerse.",

        "Intentar unir ambos fragmentos",
        "Dejar el símbolo atrás sin intervenir",

        "Los fragmentos chocan y generan un impacto que te alcanza.",
        "El símbolo vibra sin consecuencias.",
        "Conectas los fragmentos un instante y obtienes un pequeño objeto útil.",
        "El símbolo se fusiona y libera un destello energizante."
    ),

    ASAMBLEA_CAOTICA(
        "Asamblea Caótica",
        "Una asamblea improvisada gira en círculos discutiendo sin dirección alguna.",

        "Intentar aportar orden",
        "Alejarte sin atraer atención",

        "Un participante choca contigo mientras gesticula.",
        "La asamblea ignora tu presencia.",
        "Logras aportar un poco de claridad y recibes un pequeño obsequio.",
        "La asamblea se armoniza unos segundos y te transmite una energía renovadora."
    ),

    CARTA_MANIFIESTO(
        "Carta Manifiesto",
        "Encuentras una carta-manifiesto aún caliente, como si hubiera sido impresa mágicamente hace segundos.",

        "Leer la carta atentamente",
        "Dejarla y avanzar",

        "El borde de la carta te corta levemente.",
        "El manifiesto parece incoherente y no pasa nada.",
        "Encuentras un mensaje útil entre líneas.",
        "Descubres una frase oculta que te llena de vitalidad interior."
    ),

    PANCARTA_ENFURECIDA(
        "Pancarta Enfurecida",
        "Una pancarta animada protesta agitándose sola como si tuviera voluntad propia.",

        "Intentar calmar la pancarta",
        "Evitarla y seguir tu camino",

        "La pancarta te golpea con el asta.",
        "La pancarta protesta sin interactuar contigo.",
        "Logras que se calme un instante y hallas un pequeño objeto.",
        "La pancarta se vuelve amistosa y te transmite un impulso vital energético."
    ),

    BARRICADA_BUROCRATICA(
        "Barricada Burocrática",
        "Varias mesas y sillas forman una barricada con documentos de colores que parecen organizados por bandos rivales.",

        "Intentar desmontar la barricada",
        "Rodearla sin participar",

        "Una carpeta sale disparada y te roza la cara.",
        "La barricada permanece inmóvil sin afectarte.",
        "Encuentras un documento interesante entre los papeles.",
        "Al reorganizar una parte clave, la barricada emite una vibración que te robustece."
    ),

    DUELO_RETÓRICO(
        "Duelo Retórico",
        "Dos representantes se lanzan argumentos como si fueran proyectiles, generando chispas retóricas en el aire.",

        "Intervenir con un argumento conciliador",
        "Mantener distancia y no participar",

        "Un proyectil retórico explota cerca de ti.",
        "Los representantes ni se fijan en tu presencia.",
        "Tu intervención reduce la tensión y recibes un objeto útil.",
        "Generas un silencio respetuoso que se transforma en energía vital."
    ),

    MARCHA_DISONANTE(
        "Marcha Disonante",
        "Una marcha se mueve por el pasillo con cánticos contradictorios que se superponen creando un caos sonoro.",

        "Intentar armonizar los cánticos",
        "Tomar un desvío para evitar el ruido",

        "Un manifestante despistado te empuja accidentalmente.",
        "El ruido continúa sin afectarte.",
        "Logras un breve momento de coordinación y encuentras un pequeño obsequio.",
        "La marcha alcanza un instante de armonía que te fortalece profundamente."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    IdeologiaYTensiones(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
