package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum BurocraciaDisfuncional implements EnumEventoNarrativo  {

    FORMULARIO_ETERNO(
        "Formulario Eterno",
        "Te enfrentas a un mostrador infinito repleto de formularios que se contradicen entre sí.",

        "Intentar descifrar el formulario",
        "Ignorar el trámite y avanzar",

        "Intentas rellenar algo sin entenderlo y terminas lesionándote con el borde de un sello oxidado.",
        "Revisas los documentos durante un largo rato, pero no avanzas nada concreto.",
        "Encuentras una anotación marginal que simplifica todo el trámite y obtienes una poción olvidada.",
        "Descifras el sistema completo con maestría y una oleada de claridad te fortalece."
    ),

    COLA_ESPERA_INFINITA(
        "Cola de Espera Infinita",
        "Una cola eterna avanza milimétricamente mientras un panel de turnos repite los mismos números.",

        "Intentar arreglar la situación",
        "Evitar la cola y rodear el recinto",

        "Te desesperas y fuerzas el paso, chocando contra un poste metálico.",
        "Intentas reorganizar sin éxito a algunos usuarios, pero al menos no empeoras nada.",
        "Convences al guardia de seguridad para acelerar el proceso y te entrega una bebida revitalizante.",
        "Tu calma inspira a toda la cola y recibes una bendición revitalizadora."
    ),

    VENTANILLA_FANTASMA(
        "Ventanilla Fantasma",
        "Un funcionario aparece y desaparece sin explicación detrás de un cristal opaco.",

        "Interactuar con el cristal",
        "Ignorar la ventanilla y continuar",

        "Golpeas el cristal con torpeza y una astilla de vidrio te hiere.",
        "El cristal vibra, pero nada ocurre. Simplemente sigues esperando.",
        "Susurras con educación y el espíritu funcionarial regresa dándote un pequeño obsequio.",
        "El espíritu se muestra agradecido y te envuelve en una energía curativa."
    ),

    NORMATIVA_CONTRADICTORIA(
        "Normativa Contradictoria",
        "Dos documentos oficiales se contradicen completamente y nadie sabe cuál seguir.",

        "Intentar resolver la contradicción",
        "Dejar el lío burocrático atrás",

        "Sigues la peor normativa y todo se complica, causándote daño.",
        "Ignoras ambas y no pasa nada significativo por el momento.",
        "Encuentras una norma global que resuelve el conflicto y recibes una poción de agradecimiento.",
        "Descubres una laguna jurídica a tu favor que te llena de energía positiva."
    ),

    PASILLO_SIN_FIN(
        "Pasillo sin Fin",
        "Los pasillos parecen repetirse en bucle, con puertas idénticas hasta donde alcanza la vista.",

        "Intentar orientar el camino",
        "Ignorar las señales y seguir recto",

        "Giras en una esquina equivocada y tropiezas contra un archivador móvil.",
        "Deambulas sin progresar, pero sin consecuencias negativas.",
        "Descubres una salida oculta y encuentras una pequeña bendición curativa.",
        "Encuentras un acceso iluminado que te llena de vigor y claridad."
    ),

    FIRMA_IMPOSIBLE(
        "Firma Imposible",
        "Necesitas más de veinte firmas imposibles de conseguir mientras los burócratas desaparecen.",

        "Intentar conseguir alguna firma clave",
        "Dejar el documento y continuar el camino",

        "Intentas falsificar una firma y te atrapan, dañándote en el proceso.",
        "Esperas a un funcionario que nunca llega, sin ganancia ni pérdida.",
        "Encuentras una firma prefijada válida y te entregan una poción en agradecimiento.",
        "Te aceptan un modelo alternativo simplificado que te llena de motivación vital."
    ),

    ARCHIVO_PERDIDO(
        "Archivo Perdido",
        "Un funcionario te asegura que tu expediente existe, pero nadie recuerda en qué sótano, caja o universo paralelo se encuentra.",

        "Buscar personalmente entre las montañas de archivadores",
        "Asumir que el expediente nunca existió y seguir adelante",

        "Abres un archivador inestable que se desploma sobre ti en una avalancha de papeles.",
        "Revisas un par de cajas sin encontrar nada relevante.",
        "Encuentras una carpeta olvidada que contiene una pequeña poción etiquetada como 'material no inventariable'.",
        "Mientras ordenas las cajas, redescubres un documento sagrado de eficiencia administrativa que te llena de energía."
    ),

    MULTIVENTANILLA(
        "Multiventanilla",
        "Cada funcionario te envía a una ventanilla distinta. Todas dicen ser la correcta, pero ninguna puede ayudarte realmente.",

        "Intentar seguir el circuito absurdo hasta que alguna ventanilla te atienda",
        "Romper el ciclo y abandonar el edificio por otra salida",

        "Te mareas subiendo y bajando escaleras mientras vas de ventanilla en ventanilla y acabas lastimándote.",
        "Das vueltas sin rumbo y terminas en el mismo sitio donde empezaste.",
        "Encuentras a un suplente motivado que te regala una poción por no rendirte.",
        "Localizas una sala de descanso secreta donde recuperas fuerzas y aumentas tu vitalidad."
    ),

    CUNO_DESAPROBADO(
        "Cuño Desaprobado",
        "Un empleado te informa de que el sello que necesitas existe, pero el 'cuñador oficial' está revisando su propia normativa interna.",

        "Intentar convencer al cuñador para que interrumpa su proceso",
        "Renunciar al sello y abandonar la oficina",

        "El cuñador golpea accidentalmente tu mano con el sello y te causa un moratón.",
        "El cuñador te ignora mientras murmura sobre protocolos y no ocurre nada más.",
        "El cuñador se compadece de ti y te entrega una poción con aroma a tinta fresca.",
        "Te deja usar el sello maestro, cuyo poder arbitrario te revitaliza por completo."
    ),

    LABERINTO_DE_PLANTILLAS(
        "Laberinto de Plantillas",
        "Las plantillas oficiales para rellenar están duplicadas, triplicadas y contradictorias. Todas tienen campos que ninguna otra menciona.",

        "Intentar completar una plantilla coherente combinando varias",
        "Desecharlo todo y abandonar el laberinto de folios",

        "Una esquina afilada de una plantilla mal cortada te produce un pequeño corte.",
        "Das vueltas entre montones de papeles sin encontrar nada útil.",
        "Encuentras una plantilla rara con un compartimento secreto que contiene una poción.",
        "Descubres una plantilla legendaria con campos perfectamente alineados que te llena de energía vital."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    BurocraciaDisfuncional(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
