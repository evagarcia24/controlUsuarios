package es.juego.dominio.dado;

/**
 * Lanzador que siempre devuelve el mismo valor.
 * Útil para tests o reproducción de partidas.
 */
final class LanzadorFijo implements Lanzador {

    private final int fijo;

    LanzadorFijo(int fijo) {
        this.fijo = fijo;
    }

    @Override
    public int lanzar(Caras caras) {
        return fijo;
    }
}
