package es.juego.dominio.raza;

public interface Raza {

	String getTipo();

	int getFuerza();

	int getResistencia();

	int getVelocidad();

	int getMagia();
}
