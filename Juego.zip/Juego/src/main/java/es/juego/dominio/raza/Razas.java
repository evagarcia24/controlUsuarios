package es.juego.dominio.raza;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fachada pública del subdominio de razas.
 *
 * <p>Expone catálogos independientes de razas de héroe y villano, sin revelar
 * las implementaciones internas representadas por enums. Las listas y mapas
 * devueltos son siempre copias mutables para que los flujos de aplicación
 * puedan modificarlos sin afectar al dominio.
 *
 * <p>Las razas de villano están agrupadas por categorías temáticas, deducidas
 * a partir del nombre de la constante enum de {@code RazaVillanoEnum}.
 */
public final class Razas {

    private static final RazaAssembler ASSEMBLER = new RazaAssembler();

    private Razas() {
        // fachada estática, no instanciable
    }

    /**
     * Crea una raza personalizada a partir de los valores proporcionados.
     *
     * @return instancia nueva de {@link Raza}
     */
    public static Raza crear(
            String tipo,
            int fuerza,
            int resistencia,
            int velocidad,
            int magia
    ) {
        return ASSEMBLER.crear(tipo, fuerza, resistencia, velocidad, magia);
    }

    /**
     * Devuelve una lista independiente de razas de héroe.
     *
     * @return lista mutable de héroes
     */
    public static List<Raza> todasLasRazasHeroe() {

        RazaHeroeEnum[] origen = RazaHeroeEnum.values();
        List<Raza> lista = new ArrayList<Raza>(origen.length);

        for (int i = 0; i < origen.length; i++) {
            RazaHeroeEnum e = origen[i];

            Raza copia = ASSEMBLER.crear(
                    e.getTipo(),
                    e.getFuerza(),
                    e.getResistencia(),
                    e.getVelocidad(),
                    e.getMagia()
            );

            lista.add(copia);
        }

        return lista;
    }

    /**
     * Devuelve las razas de villano agrupadas por categoría temática.
     *
     * <p>La categoría se extrae del identificador del enum
     * ({@code VIL_BURO_03 → BURO}, {@code VIL_CORR_07 → CORR}, etc.).
     *
     * @return mapa de categoría → lista de razas
     */
    public static Map<String, List<Raza>> razasVillanoPorCategoria() {

        RazaVillanoEnum[] origen = RazaVillanoEnum.values();
        Map<String, List<Raza>> mapa = new HashMap<String, List<Raza>>();

        for (int i = 0; i < origen.length; i++) {

            RazaVillanoEnum e = origen[i];

            // Categoría deducida del nombre del enum
            String categoria = extraerCategoria(e.name());

            // Asegurar que exista una lista para la categoría
            List<Raza> lista = mapa.get(categoria);
            if (lista == null) {
                lista = new ArrayList<Raza>();
                mapa.put(categoria, lista);
            }

            // Crear instancia independiente de Raza
            Raza copia = ASSEMBLER.crear(
                    e.getTipo(),
                    e.getFuerza(),
                    e.getResistencia(),
                    e.getVelocidad(),
                    e.getMagia()
            );

            lista.add(copia);
        }

        return mapa;
    }

    /**
     * Extrae la categoría del nombre enum.
     * Ejemplos:
     *  - "VIL_BURO_03" → "BURO"
     *  - "VIL_CORR_10" → "CORR"
     *
     * @param nombre nombre de la constante enum
     * @return categoría extraída
     */
    private static String extraerCategoria(String nombre) {
        String[] partes = nombre.split("_");
        if (partes.length >= 2) {
            return partes[1];
        }
        return nombre;
    }
}
