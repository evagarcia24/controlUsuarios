package es.juego.dominio.raza;

/**
 * Assembler responsable de crear instancias de Raza
 * usando la implementación package-private RazaBase.
 *
 * Los flujos de aplicación controlan los valores.
 */
class RazaAssembler {

    public Raza crear(
            String tipo,
            int fuerza,
            int resistencia,
            int velocidad,
            int magia
    ) {
        return new RazaBase(
                tipo,
                fuerza,
                resistencia,
                velocidad,
                magia
        );
    }
}
