package es.juego.dominio.historia;

import java.util.List;

import es.juego.dominio.capitulo.Capitulo;
import es.juego.dominio.criatura.Criatura;

/**
 * Fachada pública del módulo de Historias.
 *
 * Esta clase expone el método de creación del agregado Historia.
 * Garantiza que toda creación o reconstrucción respete las
 * invariantes internas del modelo y delega en el ensamblador
 * correspondiente.
 *
 * No aplica reglas de negocio propias: dichas reglas pertenecen
 * exclusivamente a la capa de aplicación.
 */
public final class Historias {

    private Historias() {}

    /**
     * Crea o reconstruye una historia completa a partir de:
     *  - una lista ordenada de capítulos,
     *  - el número total de capítulos declarado,
     *  - y el villano final global de la historia.
     *
     * Este método no valida reglas narrativas externas (como evitar
     * repetir temáticas entre capítulos); dichas reglas pertenecen
     * a la capa de aplicación.
     */
    public static Historia crearOReconstruir(
            List<Capitulo> capitulos,
            int numeroCapitulos,
            Criatura villanoFinalDeHistoria
    ) {
        return HistoriaAssembler.desdeDatos(capitulos, numeroCapitulos, villanoFinalDeHistoria);
    }
}
