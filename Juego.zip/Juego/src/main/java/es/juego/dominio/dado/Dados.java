package es.juego.dominio.dado;

import java.util.function.IntSupplier;

/**
 * Fachada pública del subdominio Dado.
 * Permite crear distintos tipos de dados y distintos modos de lanzamiento.
 */
public final class Dados {

    private Dados() {}

    // ============================
    // CARAS
    // ============================

    public static Caras d10() {
        return new Caras10();
    }

    public static Caras d21() {
        return new Caras21();
    }

    // ============================
    // LANZADORES
    // ============================

    public static Lanzador automatico() {
        return new LanzadorAutomatico();
    }

    public static Lanzador interactivo(IntSupplier callback) {
        return new LanzadorInteractivo(callback);
    }

    public static Lanzador fijo(int valor) {
        return new LanzadorFijo(valor);
    }

    // ============================
    // DADO COMPLETO
    // ============================

    public static Dado crear(Caras caras, Lanzador lanzador) {
        return new Dado(caras, lanzador);
    }
}
