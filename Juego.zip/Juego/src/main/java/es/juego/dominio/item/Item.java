package es.juego.dominio.item;

/**
 * Contrato común para todos los tipos de ítems del dominio (armas, escudos,
 * pociones, ...). Esta interfaz se declara como {@code sealed} para restringir
 * explícitamente qué clases pueden implementarla.
 *
 * <p><b>Uso de sealed en Java</b><br>
 * Una interfaz o clase sellada especifica de forma explícita cuáles son las
 * implementaciones permitidas mediante la cláusula {@code permits}. Gracias a
 * ello, el compilador conoce de antemano el conjunto completo de tipos que
 * forman parte de la jerarquía, lo cual permite:
 *
 * <ul>
 *   <li><b>Exhaustividad garantizada</b> en sentencias {@code switch} sobre
 *       elementos de esta interfaz, sin necesidad de un caso {@code default}.</li>
 *
 *   <li><b>Mayor seguridad y control</b> sobre la evolución del dominio: ningún
 *       tipo externo puede implementar {@code Item} sin autorización expresa,
 *       evitando extensiones no deseadas o incoherentes.</li>
 *
 *   <li><b>Encapsulación más fuerte</b>: las implementaciones concretas
 *       (catálogos de armas, escudos, pociones) pueden permanecer como tipos
 *       internos del paquete sin exponer detalles estructurales a capas
 *       superiores.</li>
 *
 *   <li><b>Refactor más seguro</b>: si se agrega un nuevo tipo de item o se
 *       elimina uno existente, el compilador obligará a actualizar todos los
 *       puntos donde la jerarquía debe tratarse de forma exhaustiva.</li>
 * </ul>
 *
 * <p><b>Por qué se usa sealed aquí</b><br>
 * En este juego, los ítems se modelan como catálogos internos (enums) que no
 * deben ser visibles ni ampliables desde fuera del subdominio item. Declarar
 * {@code Item} como interfaz sellada garantiza:
 *
 * <ul>
 *   <li>que solo los catálogos permitidos (armas, escudos, pociones) pueden
 *       formar parte del sistema de ítems;</li>
 *   <li>que la fachada {@code Items} puede aplicar lógica basada en tipos
 *       concretos sabiendo que la enumeración es completa y estable;</li>
 *   <li>que el resto del dominio y los flujos trabajan únicamente con el
 *       contrato común sin depender de las implementaciones internas.</li>
 * </ul>
 *
 * En resumen, la interfaz sellada permite un dominio más seguro, más cerrado y
 * más coherente, controlando completamente la jerarquía de ítems y permitiendo
 * a la vez operaciones exhaustivas y predecibles dentro del paquete.
 */

public sealed interface Item permits ItemArmaEnum, ItemEscudoEnum, ItemPocionCurativaEnum {

    String getNombre();

    int getPuntos();

    int getNivel();
}
