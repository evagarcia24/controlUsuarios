package es.juego.dominio.dado;

/**
 * Define cuántas caras tiene un dado y cómo obtener una tirada.
 */
public interface Caras {
    int lanzar();
}
