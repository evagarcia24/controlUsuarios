package es.juego.dominio.evento;

import lombok.Getter;

@Getter
enum EconomiaYCrisis implements EnumEventoNarrativo  {

    MERCADO_EN_PANICO(
        "Mercado en Pánico",
        "Los indicadores económicos se desploman mientras los comerciantes corren desesperados agitando gráficos incendiados.",

        "Intentar calmar a los comerciantes",
        "Alejarte del caos financiero",

        "Un comerciante en pánico te empuja y caes sobre una caja.",
        "Los comerciantes ni te oyen y sigues igual.",
        "Un inversor agradecido te entrega un pequeño objeto valioso.",
        "Encuentras un gráfico oculto que predice estabilidad y te llena de energía positiva."
    ),

    INFLACION_DESBOCADA(
        "Inflación Desbocada",
        "Los precios de todo suben mientras observas carteles que se actualizan automáticamente cada pocos segundos.",

        "Intentar encontrar el origen del aumento",
        "Ignorar los precios y avanzar rápidamente",

        "Un panel de precios estalla y te golpea con una chispa.",
        "Los precios suben sin afectarte directamente.",
        "Descubres un cajón con vales útiles descartados.",
        "Encuentras una moneda antigua que te llena de vitalidad interior."
    ),

    RESCATE_FALLIDO(
        "Rescate Fallido",
        "Un banco colapsado intenta organizar un rescate desesperado con cajas fuertes abiertas y documentos volando.",

        "Intentar ayudar a reorganizar el rescate",
        "Abandonar la escena del colapso",

        "Una caja fuerte se cierra de golpe y te roza el brazo.",
        "Tu ayuda no sirve de mucho, pero no te afecta.",
        "Un empleado agradecido te entrega un pequeño paquete útil.",
        "Hallas un registro secreto que activa un impulso vital inesperado."
    ),

    FONDO_VOLATIL(
        "Fondo Volátil",
        "Un fondo de inversión parece cambiar de valor físicamente, expandiéndose y contrayéndose como una criatura viva.",

        "Intentar estabilizar el fondo",
        "Rodearlo sin interferir",

        "El fondo se expande bruscamente y te empuja.",
        "El fondo fluctúa sin perjudicarte.",
        "Consigues estabilizarlo un instante y recibes un pequeño beneficio.",
        "El fondo te reconoce como 'activo premium' y te refuerza con energía vital."
    ),

    TASAS_INCONTROLADAS(
        "Tasas Incontroladas",
        "Las tasas suben y bajan en pantallas que parpadean frenéticamente, afectando el ambiente a tu alrededor.",

        "Intentar descifrar el patrón de las tasas",
        "No mirar las pantallas y retirarte",

        "Una descarga estática de una pantalla te produce un pinchazo molesto.",
        "Las tasas siguen variando sin afectarte.",
        "Identificas una tendencia y recibes un pequeño recurso útil.",
        "Descubres un código económico oculto que potencia tu vitalidad."
    ),

    DEVALUACION_SUBITA(
        "Devaluación Súbita",
        "La moneda local pierde valor de forma tan rápida que las monedas comienzan a evaporarse en el aire.",

        "Intentar proteger algunas monedas",
        "Evitar la nube de evaporación",

        "Una moneda que se desintegra te provoca una pequeña quemadura.",
        "Observas la evaporación sin que te afecte.",
        "Rescatas una moneda resistente que resulta ser beneficiosa.",
        "Encuentras una moneda relicaria que revitaliza tu energía."
    ),

    CRAC_SILENCIOSO(
        "Crac Silencioso",
        "Un colapso financiero invisible ocurre a tu alrededor sin explosiones, solo con un vacío extraño en el ambiente.",

        "Analizar el origen del silencio",
        "Alejarte antes de que algo empeore",

        "Una onda silenciosa te sacude y te hace perder equilibrio.",
        "No logras entender nada, pero no sales perjudicado.",
        "Encuentras un documento útil en un cajón caído.",
        "Una vibración silenciosa armoniza contigo y refuerza tu vitalidad."
    ),

    PRESUPUESTO_FANTASMA(
        "Presupuesto Fantasma",
        "Una hoja presupuestaria escribe y borra cifras por sí sola como si fuera consciente.",

        "Intentar interpretar las cifras vivientes",
        "Dejar que el presupuesto siga su danza y marcharte",

        "El papel se arruga bruscamente y te golpea la mano.",
        "Las cifras bailan sin afectarte.",
        "Descifras un patrón fugaz y obtienes un pequeño recurso.",
        "El presupuesto te muestra una cifra dorada que eleva tu energía vital."
    ),

    AUDITORIA_INFINITA(
        "Auditoría Infinita",
        "Una auditoría interminable llena el pasillo con informes que se duplican sin control.",

        "Intentar organizar los informes",
        "Salir antes de que sigan multiplicándose",

        "Un informe mal impreso te corta un dedo.",
        "Los informes se duplican ignorándote.",
        "Encuentras un documento útil entre la pila creciente.",
        "Descubres un informe maestro que te concede una oleada de vitalidad."
    ),

    IMPUESTO_INESPERADO(
        "Impuesto Inesperado",
        "Un anuncio fiscal aparece de la nada indicando que debes pagar un impuesto completamente nuevo para poder pasar.",

        "Intentar negociar el impuesto",
        "Esquivar la notificación y avanzar por otro pasillo",

        "La notificación fiscal te golpea con una estampilla ardiente.",
        "El impuesto desaparece sin generar ningún efecto.",
        "Logras una reducción 'temporal' y recibes un pequeño obsequio.",
        "Encuentras una exención dorada que te llena de fuerza revitalizante."
    );


    private final String titulo;
    private final String descripcion;

    private final String opcion1;
    private final String opcion2;

    private final String textoFracaso;
    private final String textoNeutro;
    private final String textoExito;
    private final String textoVidaPlus;


    EconomiaYCrisis(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus) {

        this.titulo = titulo;
        this.descripcion = descripcion;

        this.opcion1 = opcion1;
        this.opcion2 = opcion2;

        this.textoFracaso = textoFracaso;
        this.textoNeutro = textoNeutro;
        this.textoExito = textoExito;
        this.textoVidaPlus = textoVidaPlus;
    }

}
