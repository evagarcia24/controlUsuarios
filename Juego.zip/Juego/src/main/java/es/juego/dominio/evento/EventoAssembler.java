package es.juego.dominio.evento;

/**
 * Ensambla objetos {@link Evento} desde enums temáticos
 * o desde datos crudos cargados de partida guardada.
 */
final class EventoAssembler {

    private EventoAssembler() {}

    /**
     * Construye un evento narrativo a partir de un enum de temática.
     * (Para generación aleatoria de capítulos, eventos, etc.)
     */
    static Evento desdeEnum(EnumEventoNarrativo origen) {

        return new EventoBase(
                origen.getTitulo(),
                origen.getDescripcion(),
                origen.getOpcion1(),
                origen.getOpcion2(),
                origen.getTextoFracaso(),
                origen.getTextoNeutro(),
                origen.getTextoExito(),
                origen.getTextoVidaPlus()
        );
    }

    /**
     * Construye un evento a partir de datos recuperados de partida guardada.
     * (Compatible con cualquier formato de persistencia.)
     */
    static Evento desdeDatos(
            String titulo,
            String descripcion,
            String opcion1,
            String opcion2,
            String textoFracaso,
            String textoNeutro,
            String textoExito,
            String textoVidaPlus
    ) {
        return new EventoBase(
                titulo,
                descripcion,
                opcion1,
                opcion2,
                textoFracaso,
                textoNeutro,
                textoExito,
                textoVidaPlus
        );
    }
}
